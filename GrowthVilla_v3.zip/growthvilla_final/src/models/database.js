const Database = require('better-sqlite3');
const bcrypt = require('bcryptjs');
const path = require('path');

const db = new Database(path.join(__dirname, '../../data/growthvilla.db'));

// Enable foreign keys
db.pragma('foreign_keys = ON');

const initializeDatabase = async () => {
  // Users table
  db.exec(`
    CREATE TABLE IF NOT EXISTS users (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      email TEXT UNIQUE NOT NULL,
      password TEXT NOT NULL,
      first_name TEXT NOT NULL,
      last_name TEXT NOT NULL,
      phone TEXT,
      nin TEXT,
      bvn TEXT,
      role TEXT DEFAULT 'user',
      is_verified INTEGER DEFAULT 0,
      verification_status TEXT DEFAULT 'pending',
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )
  `);

  // Admins table (max 2 admins)
  db.exec(`
    CREATE TABLE IF NOT EXISTS admins (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      email TEXT UNIQUE NOT NULL,
      password TEXT NOT NULL,
      first_name TEXT NOT NULL,
      last_name TEXT NOT NULL,
      phone TEXT,
      security_answer1 TEXT,
      security_answer2 TEXT,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )
  `);

  // Agents table
  db.exec(`
    CREATE TABLE IF NOT EXISTS agents (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER,
      email TEXT UNIQUE NOT NULL,
      password TEXT NOT NULL,
      first_name TEXT NOT NULL,
      last_name TEXT NOT NULL,
      phone TEXT,
      state TEXT,
      license_number TEXT,
      experience_years INTEGER,
      documents TEXT,
      is_verified INTEGER DEFAULT 0,
      verification_status TEXT DEFAULT 'pending',
      success_rate REAL DEFAULT 0,
      total_inspections INTEGER DEFAULT 0,
      successful_deals INTEGER DEFAULT 0,
      rating REAL DEFAULT 0,
      commission_earned REAL DEFAULT 0,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (user_id) REFERENCES users(id)
    )
  `);

  // Support staff table
  db.exec(`
    CREATE TABLE IF NOT EXISTS support_staff (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      email TEXT UNIQUE NOT NULL,
      password TEXT NOT NULL,
      first_name TEXT NOT NULL,
      last_name TEXT NOT NULL,
      phone TEXT,
      assigned_by INTEGER,
      is_active INTEGER DEFAULT 1,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (assigned_by) REFERENCES admins(id)
    )
  `);

  // Properties table
  db.exec(`
    CREATE TABLE IF NOT EXISTS properties (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      title TEXT NOT NULL,
      description TEXT,
      price REAL NOT NULL,
      property_type TEXT NOT NULL,
      listing_type TEXT NOT NULL,
      state TEXT NOT NULL,
      lga TEXT,
      address TEXT NOT NULL,
      bedrooms INTEGER DEFAULT 0,
      bathrooms INTEGER DEFAULT 0,
      sqm INTEGER,
      images TEXT,
      owner_id INTEGER,
      agent_id INTEGER,
      is_verified INTEGER DEFAULT 0,
      verification_status TEXT DEFAULT 'pending',
      views INTEGER DEFAULT 0,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (owner_id) REFERENCES users(id),
      FOREIGN KEY (agent_id) REFERENCES agents(id)
    )
  `);

  // Inspections table
  db.exec(`
    CREATE TABLE IF NOT EXISTS inspections (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      property_id INTEGER NOT NULL,
      user_id INTEGER NOT NULL,
      agent_id INTEGER,
      state TEXT NOT NULL,
      inspection_type TEXT NOT NULL,
      scheduled_date DATE,
      status TEXT DEFAULT 'pending',
      report_url TEXT,
      fee REAL,
      agent_fee REAL,
      payment_status TEXT DEFAULT 'pending',
      assigned_at DATETIME,
      completed_at DATETIME,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (property_id) REFERENCES properties(id),
      FOREIGN KEY (user_id) REFERENCES users(id),
      FOREIGN KEY (agent_id) REFERENCES agents(id)
    )
  `);

  // Deals/Escrow table
  db.exec(`
    CREATE TABLE IF NOT EXISTS deals (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      property_id INTEGER NOT NULL,
      buyer_id INTEGER,
      seller_id INTEGER,
      agent_id INTEGER,
      amount REAL NOT NULL,
      commission_percentage REAL DEFAULT 1.9,
      commission_amount REAL,
      escrow_status TEXT DEFAULT 'pending',
      payment_reference TEXT,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      completed_at DATETIME,
      FOREIGN KEY (property_id) REFERENCES properties(id),
      FOREIGN KEY (buyer_id) REFERENCES users(id),
      FOREIGN KEY (seller_id) REFERENCES users(id),
      FOREIGN KEY (agent_id) REFERENCES agents(id)
    )
  `);

  // Co-renting table
  db.exec(`
    CREATE TABLE IF NOT EXISTS corenting (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      property_id INTEGER,
      user_id INTEGER NOT NULL,
      title TEXT NOT NULL,
      description TEXT,
      budget_min REAL,
      budget_max REAL,
      state TEXT NOT NULL,
      area TEXT,
      preferences TEXT,
      lifestyle TEXT,
      move_in_date DATE,
      status TEXT DEFAULT 'looking',
      is_verified INTEGER DEFAULT 0,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (property_id) REFERENCES properties(id),
      FOREIGN KEY (user_id) REFERENCES users(id)
    )
  `);

  // Co-renting matches
  db.exec(`
    CREATE TABLE IF NOT EXISTS corent_matches (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      corent1_id INTEGER NOT NULL,
      corent2_id INTEGER NOT NULL,
      compatibility_score REAL,
      status TEXT DEFAULT 'pending',
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (corent1_id) REFERENCES corenting(id),
      FOREIGN KEY (corent2_id) REFERENCES corenting(id)
    )
  `);

  // Messages table
  db.exec(`
    CREATE TABLE IF NOT EXISTS messages (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      sender_id INTEGER NOT NULL,
      sender_type TEXT NOT NULL,
      receiver_id INTEGER NOT NULL,
      receiver_type TEXT NOT NULL,
      message TEXT NOT NULL,
      is_read INTEGER DEFAULT 0,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )
  `);

  // Conversations table
  db.exec(`
    CREATE TABLE IF NOT EXISTS conversations (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      participant1_id INTEGER NOT NULL,
      participant1_type TEXT NOT NULL,
      participant2_id INTEGER NOT NULL,
      participant2_type TEXT NOT NULL,
      last_message TEXT,
      last_message_at DATETIME,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )
  `);

  // Valuations table
  db.exec(`
    CREATE TABLE IF NOT EXISTS valuations (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER,
      address TEXT NOT NULL,
      state TEXT NOT NULL,
      property_type TEXT,
      bedrooms INTEGER,
      sqm INTEGER,
      estimated_value REAL,
      low_range REAL,
      high_range REAL,
      price_per_sqm REAL,
      growth_rate REAL,
      rental_yield REAL,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (user_id) REFERENCES users(id)
    )
  `);

  // Payments table
  db.exec(`
    CREATE TABLE IF NOT EXISTS payments (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER,
      amount REAL NOT NULL,
      currency TEXT DEFAULT 'NGN',
      payment_type TEXT NOT NULL,
      reference TEXT UNIQUE,
      paystack_reference TEXT,
      atarapay_reference TEXT,
      status TEXT DEFAULT 'pending',
      metadata TEXT,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (user_id) REFERENCES users(id)
    )
  `);

  // Press articles table
  db.exec(`
    CREATE TABLE IF NOT EXISTS press_articles (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      title TEXT NOT NULL,
      content TEXT NOT NULL,
      excerpt TEXT,
      author_id INTEGER,
      author_type TEXT,
      category TEXT,
      image_url TEXT,
      is_published INTEGER DEFAULT 1,
      views INTEGER DEFAULT 0,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (author_id) REFERENCES admins(id)
    )
  `);

  // Document verifications table
  db.exec(`
    CREATE TABLE IF NOT EXISTS document_verifications (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER,
      agent_id INTEGER,
      document_type TEXT NOT NULL,
      document_url TEXT,
      verification_data TEXT,
      status TEXT DEFAULT 'pending',
      verified_by INTEGER,
      verified_at DATETIME,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (user_id) REFERENCES users(id),
      FOREIGN KEY (agent_id) REFERENCES agents(id)
    )
  `);

  // AI Chat history table
  db.exec(`
    CREATE TABLE IF NOT EXISTS ai_chat_history (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER,
      user_type TEXT NOT NULL,
      message TEXT NOT NULL,
      response TEXT,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )
  `);

  // Traffic/Analytics table
  db.exec(`
    CREATE TABLE IF NOT EXISTS analytics (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      page TEXT,
      referrer TEXT,
      user_agent TEXT,
      ip_address TEXT,
      user_id INTEGER,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )
  `);

  // Shortlets table
  db.exec(`
    CREATE TABLE IF NOT EXISTS shortlets (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      property_id INTEGER,
      owner_id INTEGER,
      price_per_night REAL NOT NULL,
      amenities TEXT,
      rating REAL DEFAULT 0,
      reviews_count INTEGER DEFAULT 0,
      is_available INTEGER DEFAULT 1,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (property_id) REFERENCES properties(id),
      FOREIGN KEY (owner_id) REFERENCES users(id)
    )
  `);

  // Shortlet bookings table
  db.exec(`
    CREATE TABLE IF NOT EXISTS shortlet_bookings (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      shortlet_id INTEGER NOT NULL,
      user_id INTEGER NOT NULL,
      check_in DATE NOT NULL,
      check_out DATE NOT NULL,
      guests INTEGER DEFAULT 1,
      total_amount REAL,
      status TEXT DEFAULT 'pending',
      payment_reference TEXT,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (shortlet_id) REFERENCES shortlets(id),
      FOREIGN KEY (user_id) REFERENCES users(id)
    )
  `);

  // Feature usage tracking for non-logged in users
  db.exec(`
    CREATE TABLE IF NOT EXISTS feature_usage (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      session_id TEXT NOT NULL,
      feature_type TEXT NOT NULL,
      used_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )
  `);


  // Commission rates table
  db.exec(`
    CREATE TABLE IF NOT EXISTS commission_rates (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      role TEXT UNIQUE NOT NULL,
      rate REAL NOT NULL,
      description TEXT,
      updated_by INTEGER,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )
  `);

  // Inspection packages table
  db.exec(`
    CREATE TABLE IF NOT EXISTS inspection_packages (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      slug TEXT UNIQUE NOT NULL,
      price REAL NOT NULL,
      description TEXT,
      commission_rate REAL DEFAULT 0,
      is_active INTEGER DEFAULT 1,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )
  `);

  // Property documents table
  db.exec(`
    CREATE TABLE IF NOT EXISTS property_documents (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER NOT NULL,
      property_id INTEGER,
      document_type TEXT NOT NULL,
      document_name TEXT NOT NULL,
      document_url TEXT NOT NULL,
      file_size INTEGER,
      status TEXT DEFAULT 'pending',
      verified_by INTEGER,
      verified_at DATETIME,
      agent_notes TEXT,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (user_id) REFERENCES users(id),
      FOREIGN KEY (property_id) REFERENCES properties(id)
    )
  `);

  // Seed default commission rates
  const rateCount = db.prepare('SELECT COUNT(*) as cnt FROM commission_rates').get();
  if (rateCount.cnt === 0) {
    const insertRate = db.prepare('INSERT INTO commission_rates (role, rate, description) VALUES (?, ?, ?)');
    insertRate.run('buyer', 1.5, 'Commission charged to buyers on property transactions');
    insertRate.run('seller', 2.5, 'Commission charged to sellers on property transactions');
    insertRate.run('agent', 1.9, 'Commission earned by agents on successful deals');
  }

  // Seed default inspection packages
  const pkgCount = db.prepare('SELECT COUNT(*) as cnt FROM inspection_packages').get();
  if (pkgCount.cnt === 0) {
    const insertPkg = db.prepare('INSERT INTO inspection_packages (name, slug, price, description, commission_rate) VALUES (?, ?, ?, ?, ?)');
    insertPkg.run('Basic Snagging', 'basic', 43970, 'Visual inspection of all accessible areas', 0);
    insertPkg.run('Structural + Indepth Snagging', 'structural', 84300, 'Comprehensive structural and detailed inspection', 0);
    insertPkg.run('Title Check Only', 'title', 25000, 'Verification of property title and ownership documents', 0);
    insertPkg.run('All-in-One Complete Verification', 'all', 0, 'Full inspection + title + valuation (calculated from property value)', 2.5);
  }

  console.log('Database initialized successfully');
  return db;
};

module.exports = { db, initializeDatabase };