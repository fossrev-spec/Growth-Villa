const jwt = require('jsonwebtoken');
const { db } = require('../models/database');

const JWT_SECRET = process.env.JWT_SECRET || 'growthvilla-jwt-secret-2024';

// Generate JWT token
const generateToken = (payload) => {
  return jwt.sign(payload, JWT_SECRET, { expiresIn: '24h' });
};

// Verify JWT token
const verifyToken = (token) => {
  try {
    return jwt.verify(token, JWT_SECRET);
  } catch (error) {
    return null;
  }
};

// Authentication middleware for users
const authenticateUser = (req, res, next) => {
  const token = req.cookies?.token || req.headers.authorization?.split(' ')[1];
  
  if (!token) {
    return res.status(401).json({ error: 'Authentication required' });
  }

  const decoded = verifyToken(token);
  if (!decoded) {
    return res.status(401).json({ error: 'Invalid or expired token' });
  }

  if (decoded.role !== 'user') {
    return res.status(403).json({ error: 'Access denied' });
  }

  req.user = decoded;
  next();
};

// Authentication middleware for admins
const authenticateAdmin = (req, res, next) => {
  const token = req.cookies?.adminToken || req.headers.authorization?.split(' ')[1];
  
  if (!token) {
    return res.status(401).json({ error: 'Admin authentication required' });
  }

  const decoded = verifyToken(token);
  if (!decoded) {
    return res.status(401).json({ error: 'Invalid or expired token' });
  }

  if (decoded.role !== 'admin') {
    return res.status(403).json({ error: 'Admin access required' });
  }

  req.admin = decoded;
  next();
};

// Authentication middleware for agents
const authenticateAgent = (req, res, next) => {
  const token = req.cookies?.agentToken || req.headers.authorization?.split(' ')[1];
  
  if (!token) {
    return res.status(401).json({ error: 'Agent authentication required' });
  }

  const decoded = verifyToken(token);
  if (!decoded) {
    return res.status(401).json({ error: 'Invalid or expired token' });
  }

  if (decoded.role !== 'agent') {
    return res.status(403).json({ error: 'Agent access required' });
  }

  req.agent = decoded;
  next();
};

// Authentication middleware for support staff
const authenticateSupport = (req, res, next) => {
  const token = req.cookies?.supportToken || req.headers.authorization?.split(' ')[1];
  
  if (!token) {
    return res.status(401).json({ error: 'Support authentication required' });
  }

  const decoded = verifyToken(token);
  if (!decoded) {
    return res.status(401).json({ error: 'Invalid or expired token' });
  }

  if (decoded.role !== 'support') {
    return res.status(403).json({ error: 'Support access required' });
  }

  req.support = decoded;
  next();
};

// Optional authentication (doesn't fail if no token)
const optionalAuth = (req, res, next) => {
  const token = req.cookies?.token || req.headers.authorization?.split(' ')[1];
  
  if (token) {
    const decoded = verifyToken(token);
    if (decoded) {
      req.user = decoded;
    }
  }
  next();
};

// Check if user is verified
const requireVerification = (req, res, next) => {
  const user = db.prepare('SELECT is_verified FROM users WHERE id = ?').get(req.user.id);
  
  if (!user || !user.is_verified) {
    return res.status(403).json({ error: 'Account verification required' });
  }
  next();
};

// Check if agent is verified
const requireAgentVerification = (req, res, next) => {
  const agent = db.prepare('SELECT is_verified FROM agents WHERE id = ?').get(req.agent.id);
  
  if (!agent || !agent.is_verified) {
    return res.status(403).json({ error: 'Agent verification required' });
  }
  next();
};

module.exports = {
  generateToken,
  verifyToken,
  authenticateUser,
  authenticateAdmin,
  authenticateAgent,
  authenticateSupport,
  optionalAuth,
  requireVerification,
  requireAgentVerification
};