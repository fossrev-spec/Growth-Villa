const { db } = require('../models/database');

// Check if feature can be used (one use for non-logged in users)
function canUseFeature(sessionId, featureType) {
  try {
    const usage = db.prepare(`
      SELECT COUNT(*) as count 
      FROM feature_usage 
      WHERE session_id = ? AND feature_type = ?
    `).get(sessionId, featureType);

    return usage.count === 0;
  } catch (error) {
    console.error('Feature usage check error:', error);
    return false;
  }
}

// Record feature usage
function recordFeatureUsage(sessionId, featureType) {
  try {
    db.prepare(`
      INSERT INTO feature_usage (session_id, feature_type)
      VALUES (?, ?)
    `).run(sessionId, featureType);

    return true;
  } catch (error) {
    console.error('Record feature usage error:', error);
    return false;
  }
}

// Check and record feature usage
function checkAndRecordUsage(sessionId, featureType) {
  if (canUseFeature(sessionId, featureType)) {
    recordFeatureUsage(sessionId, featureType);
    return { allowed: true, remaining: 0 };
  }
  return { allowed: false, remaining: 0, message: 'Please login to continue using this feature' };
}

module.exports = {
  canUseFeature,
  recordFeatureUsage,
  checkAndRecordUsage
};