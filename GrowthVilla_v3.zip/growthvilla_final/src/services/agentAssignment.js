const { db } = require('../models/database');

// Auto-assign inspection to best agent in state
function assignInspectionToAgent(inspectionId, state) {
  try {
    // Get agents in that state with highest success rate and lowest pending inspections
    const bestAgent = db.prepare(`
      SELECT a.id, a.success_rate, a.total_inspections,
        (SELECT COUNT(*) FROM inspections WHERE agent_id = a.id AND status IN ('pending', 'assigned')) as pending_count
      FROM agents a
      WHERE a.state = ? AND a.is_verified = 1
      ORDER BY a.success_rate DESC, pending_count ASC, a.total_inspections DESC
      LIMIT 1
    `).get(state);

    if (bestAgent) {
      db.prepare(`
        UPDATE inspections 
        SET agent_id = ?, status = 'assigned', assigned_at = CURRENT_TIMESTAMP
        WHERE id = ?
      `).run(bestAgent.id, inspectionId);

      return bestAgent;
    }

    return null;
  } catch (error) {
    console.error('Agent assignment error:', error);
    return null;
  }
}

// Check for overdue inspections and reassign (9-day limit)
function checkAndReassignOverdueInspections() {
  try {
    // Find inspections that are assigned but not completed within 9 days
    const overdueInspections = db.prepare(`
      SELECT i.*, a.success_rate
      FROM inspections i
      JOIN agents a ON i.agent_id = a.id
      WHERE i.status = 'assigned' 
      AND datetime(i.assigned_at, '+9 days') < datetime('now')
    `).all();

    for (const inspection of overdueInspections) {
      // Find a better agent in the same state
      const betterAgent = db.prepare(`
        SELECT a.id, a.success_rate
        FROM agents a
        WHERE a.state = ? AND a.is_verified = 1 AND a.success_rate > ?
        ORDER BY a.success_rate DESC
        LIMIT 1
      `).get(inspection.state, inspection.success_rate);

      if (betterAgent) {
        // Reassign to better agent
        db.prepare(`
          UPDATE inspections 
          SET agent_id = ?, assigned_at = CURRENT_TIMESTAMP, status = 'reassigned'
          WHERE id = ?
        `).run(betterAgent.id, inspection.id);

        console.log(`Reassigned inspection ${inspection.id} to agent ${betterAgent.id}`);
      }
    }

    return overdueInspections.length;
  } catch (error) {
    console.error('Reassignment check error:', error);
    return 0;
  }
}

// Calculate agent success rate
function updateAgentSuccessRate(agentId) {
  try {
    const stats = db.prepare(`
      SELECT 
        COUNT(*) as total,
        SUM(CASE WHEN status = 'completed' THEN 1 ELSE 0 END) as completed
      FROM inspections 
      WHERE agent_id = ?
    `).get(agentId);

    if (stats.total > 0) {
      const successRate = (stats.completed / stats.total) * 100;
      db.prepare('UPDATE agents SET success_rate = ? WHERE id = ?').run(successRate, agentId);
    }
  } catch (error) {
    console.error('Update success rate error:', error);
  }
}

// Get agent performance metrics
function getAgentPerformance(agentId) {
  try {
    const metrics = db.prepare(`
      SELECT 
        a.success_rate,
        a.total_inspections,
        a.successful_deals,
        a.rating,
        a.commission_earned,
        (SELECT COUNT(*) FROM inspections WHERE agent_id = a.id AND status = 'completed') as completed_inspections,
        (SELECT COUNT(*) FROM inspections WHERE agent_id = a.id AND status IN ('pending', 'assigned')) as pending_inspections,
        (SELECT AVG(rating) FROM inspections i JOIN property_reviews pr ON i.property_id = pr.property_id WHERE i.agent_id = a.id) as avg_rating
      FROM agents a
      WHERE a.id = ?
    `).get(agentId);

    return metrics;
  } catch (error) {
    console.error('Get agent performance error:', error);
    return null;
  }
}

module.exports = {
  assignInspectionToAgent,
  checkAndReassignOverdueInspections,
  updateAgentSuccessRate,
  getAgentPerformance
};