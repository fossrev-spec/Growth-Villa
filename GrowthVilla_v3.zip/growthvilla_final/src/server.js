const express = require('express');
const session = require('express-session');
const cors = require('cors');
const cookieParser = require('cookie-parser');
const path = require('path');
const db = require('./models/database');

// Import routes
const authRoutes = require('./routes/auth');
const userRoutes = require('./routes/user');
const adminRoutes = require('./routes/admin');
const agentRoutes = require('./routes/agent');
const supportRoutes = require('./routes/support');
const propertyRoutes = require('./routes/property');
const paymentRoutes = require('./routes/payment');
const messageRoutes = require('./routes/message');
const pressRoutes = require('./routes/press');
const aiRoutes = require('./routes/ai');

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(cookieParser());
app.use(session({
  secret: process.env.SESSION_SECRET || 'growthvilla-secret-key-2024',
  resave: false,
  saveUninitialized: false,
  cookie: { 
    secure: false, 
    maxAge: 24 * 60 * 60 * 1000 // 24 hours
  }
}));

// Static files
app.use(express.static(path.join(__dirname, '../public')));

// API Routes
app.use('/api/auth', authRoutes);
app.use('/api/user', userRoutes);
app.use('/api/admin', adminRoutes);
app.use('/api/agent', agentRoutes);
app.use('/api/support', supportRoutes);
app.use('/api/property', propertyRoutes);
app.use('/api/payment', paymentRoutes);
app.use('/api/message', messageRoutes);
app.use('/api/press', pressRoutes);
app.use('/api/ai', aiRoutes);

// Serve HTML pages
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, '../public/index.html'));
});

app.get('/login', (req, res) => {
  res.sendFile(path.join(__dirname, '../public/login.html'));
});

app.get('/register', (req, res) => {
  res.sendFile(path.join(__dirname, '../public/register.html'));
});

app.get('/admin-login', (req, res) => {
  res.sendFile(path.join(__dirname, '../public/admin-login.html'));
});

app.get('/admin-register', (req, res) => {
  res.sendFile(path.join(__dirname, '../public/admin-register.html'));
});

app.get('/agent-login', (req, res) => {
  res.sendFile(path.join(__dirname, '../public/agent-login.html'));
});

app.get('/support-login', (req, res) => {
  res.sendFile(path.join(__dirname, '../public/support-login.html'));
});

app.get('/dashboard', (req, res) => {
  res.sendFile(path.join(__dirname, '../public/dashboard.html'));
});

app.get('/admin-dashboard', (req, res) => {
  res.sendFile(path.join(__dirname, '../public/admin-dashboard.html'));
});

app.get('/agent-dashboard', (req, res) => {
  res.sendFile(path.join(__dirname, '../public/agent-dashboard.html'));
});

app.get('/support-dashboard', (req, res) => {
  res.sendFile(path.join(__dirname, '../public/support-dashboard.html'));
});

app.get('/press', (req, res) => {
  res.sendFile(path.join(__dirname, '../public/press.html'));
});

// Error handling middleware
app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(500).json({ error: 'Something went wrong!' });
});

// Initialize database and start server
db.initializeDatabase().then(() => {
  app.listen(PORT, () => {
    console.log(`GrowthVilla server running on port ${PORT}`);
    console.log(`Visit http://localhost:${PORT}`);
  });
}).catch(err => {
  console.error('Failed to initialize database:', err);
  process.exit(1);
});

module.exports = app;