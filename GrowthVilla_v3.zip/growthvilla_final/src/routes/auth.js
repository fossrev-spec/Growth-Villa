const express = require('express');
const bcrypt = require('bcryptjs');
const CryptoJS = require('crypto-js');
const { db } = require('../models/database');
const { generateToken } = require('../middleware/auth');

const router = express.Router();
const ENCRYPTION_KEY = process.env.ENCRYPTION_KEY || 'growthvilla-encryption-key-2024';

// Encrypt sensitive data
const encryptData = (data) => {
  return CryptoJS.AES.encrypt(data, ENCRYPTION_KEY).toString();
};

// Decrypt sensitive data
const decryptData = (encryptedData) => {
  const bytes = CryptoJS.AES.decrypt(encryptedData, ENCRYPTION_KEY);
  return bytes.toString(CryptoJS.enc.Utf8);
};

// User Registration
router.post('/register', async (req, res) => {
  try {
    const { email, password, firstName, lastName, phone, nin, bvn } = req.body;

    // Check if user exists
    const existingUser = db.prepare('SELECT id FROM users WHERE email = ?').get(email);
    if (existingUser) {
      return res.status(400).json({ error: 'Email already registered' });
    }

    // Hash password
    const hashedPassword = await bcrypt.hash(password, 12);

    // Encrypt sensitive data
    const encryptedNin = nin ? encryptData(nin) : null;
    const encryptedBvn = bvn ? encryptData(bvn) : null;

    // Insert user
    const result = db.prepare(`
      INSERT INTO users (email, password, first_name, last_name, phone, nin, bvn)
      VALUES (?, ?, ?, ?, ?, ?, ?)
    `).run(email, hashedPassword, firstName, lastName, phone, encryptedNin, encryptedBvn);

    const token = generateToken({ id: result.lastInsertRowid, email, role: 'user' });

    res.status(201).json({
      message: 'Registration successful',
      token,
      user: {
        id: result.lastInsertRowid,
        email,
        firstName,
        lastName,
        role: 'user'
      }
    });
  } catch (error) {
    console.error('Registration error:', error);
    res.status(500).json({ error: 'Registration failed' });
  }
});

// Admin Registration (with security questions - max 2 admins)
router.post('/admin-register', async (req, res) => {
  try {
    const { email, password, firstName, lastName, phone, securityAnswer1, securityAnswer2 } = req.body;

    // Verify security questions
    // Question 1: What's your mother's maiden name? Answer: eunice
    // Question 2: What's your second name? Answer: udeme
    if (securityAnswer1.toLowerCase() !== 'eunice' || securityAnswer2.toLowerCase() !== 'udeme') {
      return res.status(400).json({ error: 'Security questions answered incorrectly' });
    }

    // Check admin count (max 2)
    const adminCount = db.prepare('SELECT COUNT(*) as count FROM admins').get();
    if (adminCount.count >= 2) {
      return res.status(400).json({ error: 'Maximum number of admins reached' });
    }

    // Check if email exists
    const existingAdmin = db.prepare('SELECT id FROM admins WHERE email = ?').get(email);
    if (existingAdmin) {
      return res.status(400).json({ error: 'Email already registered' });
    }

    // Hash password and security answers
    const hashedPassword = await bcrypt.hash(password, 12);
    const hashedAnswer1 = await bcrypt.hash(securityAnswer1.toLowerCase(), 10);
    const hashedAnswer2 = await bcrypt.hash(securityAnswer2.toLowerCase(), 10);

    const result = db.prepare(`
      INSERT INTO admins (email, password, first_name, last_name, phone, security_answer1, security_answer2)
      VALUES (?, ?, ?, ?, ?, ?, ?)
    `).run(email, hashedPassword, firstName, lastName, phone, hashedAnswer1, hashedAnswer2);

    const token = generateToken({ id: result.lastInsertRowid, email, role: 'admin' });

    res.status(201).json({
      message: 'Admin registration successful',
      token,
      admin: {
        id: result.lastInsertRowid,
        email,
        firstName,
        lastName,
        role: 'admin'
      }
    });
  } catch (error) {
    console.error('Admin registration error:', error);
    res.status(500).json({ error: 'Admin registration failed' });
  }
});

// User Login
router.post('/login', async (req, res) => {
  try {
    const { email, password } = req.body;

    const user = db.prepare('SELECT * FROM users WHERE email = ?').get(email);
    if (!user) {
      return res.status(401).json({ error: 'Invalid credentials' });
    }

    const isValidPassword = await bcrypt.compare(password, user.password);
    if (!isValidPassword) {
      return res.status(401).json({ error: 'Invalid credentials' });
    }

    const token = generateToken({ id: user.id, email: user.email, role: 'user' });

    res.json({
      message: 'Login successful',
      token,
      user: {
        id: user.id,
        email: user.email,
        firstName: user.first_name,
        lastName: user.last_name,
        role: 'user',
        isVerified: user.is_verified
      }
    });
  } catch (error) {
    console.error('Login error:', error);
    res.status(500).json({ error: 'Login failed' });
  }
});

// Admin Login
router.post('/admin-login', async (req, res) => {
  try {
    const { email, password } = req.body;

    const admin = db.prepare('SELECT * FROM admins WHERE email = ?').get(email);
    if (!admin) {
      return res.status(401).json({ error: 'Invalid credentials' });
    }

    const isValidPassword = await bcrypt.compare(password, admin.password);
    if (!isValidPassword) {
      return res.status(401).json({ error: 'Invalid credentials' });
    }

    const token = generateToken({ id: admin.id, email: admin.email, role: 'admin' });

    res.json({
      message: 'Admin login successful',
      token,
      admin: {
        id: admin.id,
        email: admin.email,
        firstName: admin.first_name,
        lastName: admin.last_name,
        role: 'admin'
      }
    });
  } catch (error) {
    console.error('Admin login error:', error);
    res.status(500).json({ error: 'Admin login failed' });
  }
});

// Agent Registration
router.post('/agent-register', async (req, res) => {
  try {
    const { email, password, firstName, lastName, phone, state, licenseNumber, experienceYears } = req.body;

    // Check if agent exists
    const existingAgent = db.prepare('SELECT id FROM agents WHERE email = ?').get(email);
    if (existingAgent) {
      return res.status(400).json({ error: 'Email already registered' });
    }

    const hashedPassword = await bcrypt.hash(password, 12);

    const result = db.prepare(`
      INSERT INTO agents (email, password, first_name, last_name, phone, state, license_number, experience_years)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    `).run(email, hashedPassword, firstName, lastName, phone, state, licenseNumber, experienceYears);

    const token = generateToken({ id: result.lastInsertRowid, email, role: 'agent' });

    res.status(201).json({
      message: 'Agent registration successful. Awaiting verification.',
      token,
      agent: {
        id: result.lastInsertRowid,
        email,
        firstName,
        lastName,
        state,
        role: 'agent',
        verificationStatus: 'pending'
      }
    });
  } catch (error) {
    console.error('Agent registration error:', error);
    res.status(500).json({ error: 'Agent registration failed' });
  }
});

// Agent Login
router.post('/agent-login', async (req, res) => {
  try {
    const { email, password } = req.body;

    const agent = db.prepare('SELECT * FROM agents WHERE email = ?').get(email);
    if (!agent) {
      return res.status(401).json({ error: 'Invalid credentials' });
    }

    const isValidPassword = await bcrypt.compare(password, agent.password);
    if (!isValidPassword) {
      return res.status(401).json({ error: 'Invalid credentials' });
    }

    const token = generateToken({ id: agent.id, email: agent.email, role: 'agent' });

    res.json({
      message: 'Agent login successful',
      token,
      agent: {
        id: agent.id,
        email: agent.email,
        firstName: agent.first_name,
        lastName: agent.last_name,
        state: agent.state,
        role: 'agent',
        isVerified: agent.is_verified
      }
    });
  } catch (error) {
    console.error('Agent login error:', error);
    res.status(500).json({ error: 'Agent login failed' });
  }
});

// Support Staff Login
router.post('/support-login', async (req, res) => {
  try {
    const { email, password } = req.body;

    const support = db.prepare('SELECT * FROM support_staff WHERE email = ?').get(email);
    if (!support) {
      return res.status(401).json({ error: 'Invalid credentials' });
    }

    if (!support.is_active) {
      return res.status(403).json({ error: 'Account deactivated' });
    }

    const isValidPassword = await bcrypt.compare(password, support.password);
    if (!isValidPassword) {
      return res.status(401).json({ error: 'Invalid credentials' });
    }

    const token = generateToken({ id: support.id, email: support.email, role: 'support' });

    res.json({
      message: 'Support login successful',
      token,
      support: {
        id: support.id,
        email: support.email,
        firstName: support.first_name,
        lastName: support.last_name,
        role: 'support'
      }
    });
  } catch (error) {
    console.error('Support login error:', error);
    res.status(500).json({ error: 'Support login failed' });
  }
});

// Logout
router.post('/logout', (req, res) => {
  res.clearCookie('token');
  res.clearCookie('adminToken');
  res.clearCookie('agentToken');
  res.clearCookie('supportToken');
  res.json({ message: 'Logged out successfully' });
});

// Get current user
router.get('/me', (req, res) => {
  const token = req.cookies?.token || req.headers.authorization?.split(' ')[1];
  
  if (!token) {
    return res.status(401).json({ error: 'Not authenticated' });
  }

  const decoded = require('../middleware/auth').verifyToken(token);
  if (!decoded) {
    return res.status(401).json({ error: 'Invalid token' });
  }

  if (decoded.role === 'user') {
    const user = db.prepare('SELECT id, email, first_name, last_name, phone, is_verified, verification_status FROM users WHERE id = ?').get(decoded.id);
    return res.json({ user: { ...user, role: 'user' } });
  } else if (decoded.role === 'admin') {
    const admin = db.prepare('SELECT id, email, first_name, last_name FROM admins WHERE id = ?').get(decoded.id);
    return res.json({ admin: { ...admin, role: 'admin' } });
  } else if (decoded.role === 'agent') {
    const agent = db.prepare('SELECT id, email, first_name, last_name, state, is_verified FROM agents WHERE id = ?').get(decoded.id);
    return res.json({ agent: { ...agent, role: 'agent' } });
  } else if (decoded.role === 'support') {
    const support = db.prepare('SELECT id, email, first_name, last_name FROM support_staff WHERE id = ?').get(decoded.id);
    return res.json({ support: { ...support, role: 'support' } });
  }

  res.status(400).json({ error: 'Unknown role' });
});

module.exports = router;