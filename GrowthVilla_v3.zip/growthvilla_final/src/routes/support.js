const express = require('express');
const { db } = require('../models/database');
const { authenticateSupport } = require('../middleware/auth');

const router = express.Router();

// Get support dashboard stats
router.get('/stats', authenticateSupport, (req, res) => {
  try {
    const pendingUserVerifications = db.prepare(`
      SELECT COUNT(*) as count FROM users WHERE verification_status = 'pending'
    `).get();

    const pendingAgentVerifications = db.prepare(`
      SELECT COUNT(*) as count FROM agents WHERE verification_status = 'pending'
    `).get();

    const pendingDocumentVerifications = db.prepare(`
      SELECT COUNT(*) as count FROM document_verifications WHERE status = 'pending'
    `).get();

    const pendingInspections = db.prepare(`
      SELECT COUNT(*) as count FROM inspections WHERE status = 'pending'
    `).get();

    res.json({
      stats: {
        pendingUserVerifications: pendingUserVerifications.count,
        pendingAgentVerifications: pendingAgentVerifications.count,
        pendingDocumentVerifications: pendingDocumentVerifications.count,
        pendingInspections: pendingInspections.count
      }
    });
  } catch (error) {
    console.error('Stats error:', error);
    res.status(500).json({ error: 'Failed to fetch stats' });
  }
});

// Get pending user verifications
router.get('/verifications/users', authenticateSupport, (req, res) => {
  try {
    const users = db.prepare(`
      SELECT id, email, first_name, last_name, phone, nin, bvn, verification_status, created_at
      FROM users WHERE verification_status = 'pending' ORDER BY created_at ASC
    `).all();

    res.json({ users });
  } catch (error) {
    console.error('User verifications error:', error);
    res.status(500).json({ error: 'Failed to fetch user verifications' });
  }
});

// Verify user (manual)
router.put('/verifications/users/:id', authenticateSupport, (req, res) => {
  try {
    const { status, notes } = req.body;

    db.prepare(`
      UPDATE users 
      SET is_verified = ?, verification_status = ?
      WHERE id = ?
    `).run(status === 'approved' ? 1 : 0, status, req.params.id);

    res.json({ message: 'User verification updated' });
  } catch (error) {
    console.error('Verify user error:', error);
    res.status(500).json({ error: 'Failed to update verification' });
  }
});

// Get pending agent verifications
router.get('/verifications/agents', authenticateSupport, (req, res) => {
  try {
    const agents = db.prepare(`
      SELECT id, email, first_name, last_name, phone, state, license_number, experience_years, documents, verification_status, created_at
      FROM agents WHERE verification_status = 'pending' ORDER BY created_at ASC
    `).all();

    res.json({ agents });
  } catch (error) {
    console.error('Agent verifications error:', error);
    res.status(500).json({ error: 'Failed to fetch agent verifications' });
  }
});

// Verify agent (manual)
router.put('/verifications/agents/:id', authenticateSupport, (req, res) => {
  try {
    const { status, notes } = req.body;

    db.prepare(`
      UPDATE agents 
      SET is_verified = ?, verification_status = ?
      WHERE id = ?
    `).run(status === 'approved' ? 1 : 0, status, req.params.id);

    res.json({ message: 'Agent verification updated' });
  } catch (error) {
    console.error('Verify agent error:', error);
    res.status(500).json({ error: 'Failed to update verification' });
  }
});

// Get pending document verifications
router.get('/verifications/documents', authenticateSupport, (req, res) => {
  try {
    const documents = db.prepare(`
      SELECT dv.*, 
        u.first_name as user_name, a.first_name as agent_name
      FROM document_verifications dv
      LEFT JOIN users u ON dv.user_id = u.id
      LEFT JOIN agents a ON dv.agent_id = a.id
      WHERE dv.status = 'pending' ORDER BY dv.created_at ASC
    `).all();

    res.json({ documents });
  } catch (error) {
    console.error('Document verifications error:', error);
    res.status(500).json({ error: 'Failed to fetch document verifications' });
  }
});

// Verify document (manual)
router.put('/verifications/documents/:id', authenticateSupport, (req, res) => {
  try {
    const { status } = req.body;

    db.prepare(`
      UPDATE document_verifications 
      SET status = ?, verified_by = ?, verified_at = CURRENT_TIMESTAMP
      WHERE id = ?
    `).run(status, req.support.id, req.params.id);

    res.json({ message: 'Document verification updated' });
  } catch (error) {
    console.error('Verify document error:', error);
    res.status(500).json({ error: 'Failed to update verification' });
  }
});

// Automatic document verification (NIN/BVN simulation)
router.post('/verifications/auto', authenticateSupport, (req, res) => {
  try {
    const { type, number } = req.body;

    // Simulate NIN/BVN verification with Nigerian government databases
    const isValid = Math.random() > 0.1; // 90% success rate simulation

    res.json({
      verified: isValid,
      message: isValid ? `${type} verified successfully` : `${type} verification failed`,
      timestamp: new Date().toISOString()
    });
  } catch (error) {
    console.error('Auto verification error:', error);
    res.status(500).json({ error: 'Failed to verify' });
  }
});

// Property title search verification
router.post('/title-search', authenticateSupport, (req, res) => {
  try {
    const { propertyId, searchType } = req.body;

    // Simulate title search from Nigerian property valuation sites
    const sources = {
      lagos: { name: 'Lagos e-GIS', url: 'https://lagosstate.gov.ng/e-gis' },
      abuja: { name: 'Abuja AGIS', url: 'https://agis.abuja.gov.ng' },
      rivers: { name: 'Rivers GIS', url: 'https://riversstate.gov.ng/gis' },
      other: { name: 'State Land Registry', url: 'https://nigeria.gov.ng/lands' }
    };

    const source = sources[searchType] || sources.other;

    // Simulate verification data
    const titleData = {
      status: 'verified',
      source: source.name,
      sourceUrl: source.url,
      verifiedAt: new Date().toISOString(),
      propertyDetails: {
        titleNumber: `TN-${Date.now()}`,
        landArea: '500 sqm',
        ownerVerified: true,
        encumbrances: 'None'
      }
    };

    // Update property
    db.prepare(`
      UPDATE properties SET verification_status = 'title_verified', is_verified = 1
      WHERE id = ?
    `).run(propertyId);

    res.json({ titleData });
  } catch (error) {
    console.error('Title search error:', error);
    res.status(500).json({ error: 'Failed to perform title search' });
  }
});

// Get pending inspections needing assignment
router.get('/inspections/pending', authenticateSupport, (req, res) => {
  try {
    const inspections = db.prepare(`
      SELECT i.*, p.title, p.address, p.state, p.price
      FROM inspections i
      JOIN properties p ON i.property_id = p.id
      WHERE i.status = 'pending' AND i.agent_id IS NULL
      ORDER BY i.created_at ASC
    `).all();

    res.json({ inspections });
  } catch (error) {
    console.error('Pending inspections error:', error);
    res.status(500).json({ error: 'Failed to fetch pending inspections' });
  }
});

// Assign inspection to agent
router.post('/inspections/:id/assign', authenticateSupport, (req, res) => {
  try {
    const { agentId } = req.body;
    const inspectionId = req.params.id;

    // Get inspection details
    const inspection = db.prepare('SELECT * FROM inspections WHERE id = ?').get(inspectionId);
    if (!inspection) {
      return res.status(404).json({ error: 'Inspection not found' });
    }

    // Assign agent
    db.prepare(`
      UPDATE inspections 
      SET agent_id = ?, status = 'assigned', assigned_at = CURRENT_TIMESTAMP
      WHERE id = ?
    `).run(agentId, inspectionId);

    res.json({ message: 'Inspection assigned successfully' });
  } catch (error) {
    console.error('Assign inspection error:', error);
    res.status(500).json({ error: 'Failed to assign inspection' });
  }
});

// Get all messages for support
router.get('/messages', authenticateSupport, (req, res) => {
  try {
    const messages = db.prepare(`
      SELECT m.*, 
        CASE 
          WHEN m.sender_type = 'user' THEN u.first_name
          WHEN m.sender_type = 'agent' THEN a.first_name
          ELSE 'Unknown'
        END as sender_name
      FROM messages m
      LEFT JOIN users u ON m.sender_type = 'user' AND m.sender_id = u.id
      LEFT JOIN agents a ON m.sender_type = 'agent' AND m.sender_id = a.id
      WHERE m.receiver_type = 'support'
      ORDER BY m.created_at DESC
    `).all();

    res.json({ messages });
  } catch (error) {
    console.error('Messages error:', error);
    res.status(500).json({ error: 'Failed to fetch messages' });
  }
});

// Create press article
router.post('/press', authenticateSupport, (req, res) => {
  try {
    const { title, content, excerpt, category, imageUrl } = req.body;

    const result = db.prepare(`
      INSERT INTO press_articles (title, content, excerpt, author_id, author_type, category, image_url)
      VALUES (?, ?, ?, ?, 'support', ?, ?)
    `).run(title, content, excerpt, req.support.id, category, imageUrl);

    res.status(201).json({ message: 'Article created', id: result.lastInsertRowid });
  } catch (error) {
    console.error('Create article error:', error);
    res.status(500).json({ error: 'Failed to create article' });
  }
});

module.exports = router;