const express = require('express');
const { db } = require('../models/database');
const { optionalAuth } = require('../middleware/auth');

const router = express.Router();

// AI Chat endpoint
router.post('/chat', optionalAuth, async (req, res) => {
  try {
    const { message, context } = req.body;
    const userId = req.user?.id || null;
    const userType = req.user?.role || 'guest';

    // Generate AI response based on context
    let response = '';

    const lowerMessage = message.toLowerCase();

    // Property-related queries
    if (lowerMessage.includes('property') || lowerMessage.includes('house') || lowerMessage.includes('flat')) {
      response = generatePropertyResponse(message);
    }
    // Valuation queries
    else if (lowerMessage.includes('valuation') || lowerMessage.includes('value') || lowerMessage.includes('price')) {
      response = generateValuationResponse(message);
    }
    // Verification queries
    else if (lowerMessage.includes('verify') || lowerMessage.includes('inspection') || lowerMessage.includes('document')) {
      response = generateVerificationResponse(message);
    }
    // Co-renting queries
    else if (lowerMessage.includes('co-rent') || lowerMessage.includes('flatmate') || lowerMessage.includes('roommate')) {
      response = generateCorentingResponse(message);
    }
    // Shortlet queries
    else if (lowerMessage.includes('shortlet') || lowerMessage.includes('short stay') || lowerMessage.includes('temporary')) {
      response = generateShortletResponse(message);
    }
    // Payment queries
    else if (lowerMessage.includes('pay') || lowerMessage.includes('escrow') || lowerMessage.includes('transfer')) {
      response = generatePaymentResponse(message);
    }
    // General help
    else {
      response = generateGeneralResponse(message);
    }

    // Save chat history
    if (userId) {
      db.prepare(`
        INSERT INTO ai_chat_history (user_id, user_type, message, response)
        VALUES (?, ?, ?, ?)
      `).run(userId, userType, message, response);
    }

    res.json({ response });
  } catch (error) {
    console.error('AI chat error:', error);
    res.status(500).json({ error: 'Failed to process chat' });
  }
});

// Get chat history
router.get('/history', optionalAuth, (req, res) => {
  try {
    if (!req.user) {
      return res.json({ history: [] });
    }

    const history = db.prepare(`
      SELECT message, response, created_at
      FROM ai_chat_history
      WHERE user_id = ? AND user_type = ?
      ORDER BY created_at DESC
      LIMIT 50
    `).all(req.user.id, req.user.role);

    res.json({ history });
  } catch (error) {
    console.error('Chat history error:', error);
    res.status(500).json({ error: 'Failed to fetch chat history' });
  }
});

// Helper functions for AI responses
function generatePropertyResponse(message) {
  const responses = [
    "I can help you find properties across all 36 Nigerian states! You can search by location, price range, property type, and number of bedrooms. Would you like to see properties for sale, rent, or shortlet?",
    "GrowthVilla has over 4,800 verified properties. Each listing includes inspection reports, title verification, and agent details. What type of property are you looking for?",
    "Our properties are verified by certified agents and come with comprehensive inspection reports. You can browse by state - Lagos, Abuja, Rivers, and many more. What's your preferred location?"
  ];
  return responses[Math.floor(Math.random() * responses.length)];
}

function generateValuationResponse(message) {
  const responses = [
    "Our GrowthEstimate™ tool provides instant property valuations using data from Lagos e-GIS, Abuja AGIS, and 36 state land registries. Just enter the property address and details to get an estimate.",
    "Property valuations on GrowthVilla are powered by real market data from government sources. The average property in Lagos has grown 39.5% year-over-year. Would you like a valuation?",
    "I can help you estimate a property's value. Our algorithm considers location, size, property type, and recent comparable sales. What property would you like to value?"
  ];
  return responses[Math.floor(Math.random() * responses.length)];
}

function generateVerificationResponse(message) {
  const responses = [
    "Property verification on GrowthVilla includes title search via government portals (e-GIS, AGIS), physical inspection by certified agents, and document verification. The fee ranges from 1-3% of the property price.",
    "Our verification process takes 24-48 hours. We check land titles, conduct snagging inspections with 200+ checkpoints, and provide a comprehensive PDF report. Would you like to book an inspection?",
    "All verified properties on GrowthVilla have passed our rigorous 15-point verification process. This includes title verification, physical inspection, and agent authentication. How can I help you verify a property?"
  ];
  return responses[Math.floor(Math.random() * responses.length)];
}

function generateCorentingResponse(message) {
  const responses = [
    "Our co-renting platform matches verified flatmates across Nigeria. Each user is ID-verified with NIN or BVN. We also provide AI compatibility matching based on lifestyle preferences!",
    "Looking for a flatmate? GrowthVilla's co-renting feature helps you find compatible roommates. We verify all users and provide legal co-tenancy agreements. What's your budget range?",
    "Co-renting on GrowthVilla includes deposit protection through escrow, in-app messaging, and lifestyle matching. Available in Lagos, Abuja, Rivers, and 33 other states. Where are you looking?"
  ];
  return responses[Math.floor(Math.random() * responses.length)];
}

function generateShortletResponse(message) {
  const responses = [
    "Our shortlet apartments are fully furnished and hotel-quality. Prices range from ₦35,000 to ₦150,000 per night depending on location and amenities. Popular areas include Ikoyi, Lekki, and Maitama.",
    "Looking for a shortlet? We have verified apartments in Lagos, Abuja, Port Harcourt, and more. Each listing includes ratings, amenities, and instant booking. How many nights do you need?",
    "GrowthVilla shortlets come with WiFi, AC, security, and more. We verify all properties and offer secure payment through Paystack. What dates are you looking to book?"
  ];
  return responses[Math.floor(Math.random() * responses.length)];
}

function generatePaymentResponse(message) {
  const responses = [
    "GrowthVilla uses secure payment gateways. For inspections, we use Paystack. For deals, we use AtaraPay escrow to protect both buyers and sellers. The platform fee is 1.9% from each party.",
    "All payments on GrowthVilla are secured. Inspection fees start at ₦45,000, and our escrow system ensures funds are released only when both parties are satisfied. Do you have payment questions?",
    "For property deals, GrowthVilla charges 1.9% commission from both buyer and seller (0.5% for co-renting). Payments are processed securely through Paystack and AtaraPay escrow."
  ];
  return responses[Math.floor(Math.random() * responses.length)];
}

function generateGeneralResponse(message) {
  const responses = [
    "Welcome to GrowthVilla! I'm your AI assistant. I can help you with property searches, valuations, inspections, co-renting, shortlets, and payments. What would you like to know?",
    "GrowthVilla is Nigeria's #1 verified property platform. We offer property listings, GrowthEstimate™ valuations, inspection booking, co-renting matching, and secure escrow payments. How can I assist you today?",
    "I'm here to help! You can ask me about finding properties, getting valuations, booking inspections, finding flatmates, booking shortlets, or making payments. What interests you?"
  ];
  return responses[Math.floor(Math.random() * responses.length)];
}

module.exports = router;