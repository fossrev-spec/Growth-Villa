const express = require('express');
const { db } = require('../models/database');
const { authenticateUser, authenticateAgent, authenticateSupport } = require('../middleware/auth');

const router = express.Router();

// Get conversations for user
router.get('/conversations', authenticateUser, (req, res) => {
  try {
    const conversations = db.prepare(`
      SELECT c.*, 
        CASE 
          WHEN c.participant2_type = 'user' THEN u.first_name
          WHEN c.participant2_type = 'agent' THEN a.first_name
          WHEN c.participant2_type = 'support' THEN s.first_name
        END as other_name,
        c.participant2_type as other_type
      FROM conversations c
      LEFT JOIN users u ON c.participant2_type = 'user' AND c.participant2_id = u.id
      LEFT JOIN agents a ON c.participant2_type = 'agent' AND c.participant2_id = a.id
      LEFT JOIN support_staff s ON c.participant2_type = 'support' AND c.participant2_id = s.id
      WHERE c.participant1_id = ? AND c.participant1_type = 'user'
      OR c.participant2_id = ? AND c.participant2_type = 'user'
      ORDER BY c.last_message_at DESC
    `).all(req.user.id, req.user.id);

    res.json({ conversations });
  } catch (error) {
    console.error('Conversations error:', error);
    res.status(500).json({ error: 'Failed to fetch conversations' });
  }
});

// Get messages in conversation
router.get('/conversations/:id', authenticateUser, (req, res) => {
  try {
    const messages = db.prepare(`
      SELECT * FROM messages
      WHERE (sender_id = ? AND sender_type = 'user' AND receiver_id = ?)
      OR (receiver_id = ? AND receiver_type = 'user' AND sender_id = ?)
      ORDER BY created_at ASC
    `).all(req.user.id, req.params.id, req.user.id, req.params.id);

    // Mark as read
    db.prepare(`
      UPDATE messages SET is_read = 1
      WHERE receiver_id = ? AND receiver_type = 'user' AND sender_id = ?
    `).run(req.user.id, req.params.id);

    res.json({ messages });
  } catch (error) {
    console.error('Messages error:', error);
    res.status(500).json({ error: 'Failed to fetch messages' });
  }
});

// Send message (user)
router.post('/send', authenticateUser, (req, res) => {
  try {
    const { receiverId, receiverType, message } = req.body;

    const result = db.prepare(`
      INSERT INTO messages (sender_id, sender_type, receiver_id, receiver_type, message)
      VALUES (?, 'user', ?, ?, ?)
    `).run(req.user.id, receiverId, receiverType, message);

    // Update or create conversation
    const existingConversation = db.prepare(`
      SELECT id FROM conversations
      WHERE (participant1_id = ? AND participant1_type = 'user' AND participant2_id = ? AND participant2_type = ?)
      OR (participant1_id = ? AND participant1_type = ? AND participant2_id = ? AND participant2_type = 'user')
    `).get(req.user.id, receiverId, receiverType, receiverId, receiverType, req.user.id);

    if (existingConversation) {
      db.prepare(`
        UPDATE conversations SET last_message = ?, last_message_at = CURRENT_TIMESTAMP
        WHERE id = ?
      `).run(message, existingConversation.id);
    } else {
      db.prepare(`
        INSERT INTO conversations (participant1_id, participant1_type, participant2_id, participant2_type, last_message, last_message_at)
        VALUES (?, 'user', ?, ?, ?, CURRENT_TIMESTAMP)
      `).run(req.user.id, receiverId, receiverType, message);
    }

    res.status(201).json({ message: 'Message sent', id: result.lastInsertRowid });
  } catch (error) {
    console.error('Send message error:', error);
    res.status(500).json({ error: 'Failed to send message' });
  }
});

// Agent messaging
router.post('/agent/send', authenticateAgent, (req, res) => {
  try {
    const { receiverId, receiverType, message } = req.body;

    const result = db.prepare(`
      INSERT INTO messages (sender_id, sender_type, receiver_id, receiver_type, message)
      VALUES (?, 'agent', ?, ?, ?)
    `).run(req.agent.id, receiverId, receiverType, message);

    res.status(201).json({ message: 'Message sent', id: result.lastInsertRowid });
  } catch (error) {
    console.error('Send message error:', error);
    res.status(500).json({ error: 'Failed to send message' });
  }
});

// Support messaging
router.post('/support/send', authenticateSupport, (req, res) => {
  try {
    const { receiverId, receiverType, message } = req.body;

    const result = db.prepare(`
      INSERT INTO messages (sender_id, sender_type, receiver_id, receiver_type, message)
      VALUES (?, 'support', ?, ?, ?)
    `).run(req.support.id, receiverId, receiverType, message);

    res.status(201).json({ message: 'Message sent', id: result.lastInsertRowid });
  } catch (error) {
    console.error('Send message error:', error);
    res.status(500).json({ error: 'Failed to send message' });
  }
});

// Get unread count
router.get('/unread', authenticateUser, (req, res) => {
  try {
    const unread = db.prepare(`
      SELECT COUNT(*) as count FROM messages
      WHERE receiver_id = ? AND receiver_type = 'user' AND is_read = 0
    `).get(req.user.id);

    res.json({ unread: unread.count });
  } catch (error) {
    console.error('Unread count error:', error);
    res.status(500).json({ error: 'Failed to get unread count' });
  }
});

module.exports = router;