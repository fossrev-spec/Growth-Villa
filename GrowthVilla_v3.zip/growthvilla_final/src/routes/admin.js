const express = require('express');
const bcrypt = require('bcryptjs');
const { db } = require('../models/database');
const { authenticateAdmin } = require('../middleware/auth');

const router = express.Router();

// Get admin dashboard stats
router.get('/stats', authenticateAdmin, (req, res) => {
  try {
    const totalUsers = db.prepare('SELECT COUNT(*) as count FROM users').get();
    const activeUsers = db.prepare('SELECT COUNT(*) as count FROM users WHERE is_verified = 1').get();
    const totalAgents = db.prepare('SELECT COUNT(*) as count FROM agents').get();
    const verifiedAgents = db.prepare('SELECT COUNT(*) as count FROM agents WHERE is_verified = 1').get();
    const totalProperties = db.prepare('SELECT COUNT(*) as count FROM properties').get();
    const totalInspections = db.prepare('SELECT COUNT(*) as count FROM inspections').get();
    const pendingInspections = db.prepare('SELECT COUNT(*) as count FROM inspections WHERE status = "pending"').get();
    const totalDeals = db.prepare('SELECT COUNT(*) as count FROM deals').get();
    const completedDeals = db.prepare('SELECT COUNT(*) as count FROM deals WHERE escrow_status = "completed"').get();
    const totalRevenue = db.prepare('SELECT SUM(commission_amount) as total FROM deals WHERE escrow_status = "completed"').get();

    res.json({
      stats: {
        users: { total: totalUsers.count, active: activeUsers.count },
        agents: { total: totalAgents.count, verified: verifiedAgents.count },
        properties: totalProperties.count,
        inspections: { total: totalInspections.count, pending: pendingInspections.count },
        deals: { total: totalDeals.count, completed: completedDeals.count },
        revenue: totalRevenue.total || 0
      }
    });
  } catch (error) {
    console.error('Stats error:', error);
    res.status(500).json({ error: 'Failed to fetch stats' });
  }
});

// Get all users
router.get('/users', authenticateAdmin, (req, res) => {
  try {
    const users = db.prepare(`
      SELECT id, email, first_name, last_name, phone, is_verified, verification_status, created_at
      FROM users ORDER BY created_at DESC
    `).all();

    res.json({ users });
  } catch (error) {
    console.error('Users error:', error);
    res.status(500).json({ error: 'Failed to fetch users' });
  }
});

// Verify user
router.put('/users/:id/verify', authenticateAdmin, (req, res) => {
  try {
    db.prepare('UPDATE users SET is_verified = 1, verification_status = "verified" WHERE id = ?').run(req.params.id);
    res.json({ message: 'User verified successfully' });
  } catch (error) {
    console.error('Verify user error:', error);
    res.status(500).json({ error: 'Failed to verify user' });
  }
});

// Get all agents
router.get('/agents', authenticateAdmin, (req, res) => {
  try {
    const agents = db.prepare(`
      SELECT id, email, first_name, last_name, phone, state, is_verified, verification_status, success_rate, total_inspections, created_at
      FROM agents ORDER BY created_at DESC
    `).all();

    res.json({ agents });
  } catch (error) {
    console.error('Agents error:', error);
    res.status(500).json({ error: 'Failed to fetch agents' });
  }
});

// Verify agent
router.put('/agents/:id/verify', authenticateAdmin, (req, res) => {
  try {
    db.prepare('UPDATE agents SET is_verified = 1, verification_status = "verified" WHERE id = ?').run(req.params.id);
    res.json({ message: 'Agent verified successfully' });
  } catch (error) {
    console.error('Verify agent error:', error);
    res.status(500).json({ error: 'Failed to verify agent' });
  }
});

// Get support staff
router.get('/support-staff', authenticateAdmin, (req, res) => {
  try {
    const staff = db.prepare(`
      SELECT s.*, a.first_name as assigned_by_name
      FROM support_staff s
      LEFT JOIN admins a ON s.assigned_by = a.id
      ORDER BY s.created_at DESC
    `).all();

    res.json({ staff });
  } catch (error) {
    console.error('Support staff error:', error);
    res.status(500).json({ error: 'Failed to fetch support staff' });
  }
});

// Create support staff
router.post('/support-staff', authenticateAdmin, async (req, res) => {
  try {
    const { email, password, firstName, lastName, phone } = req.body;

    const existing = db.prepare('SELECT id FROM support_staff WHERE email = ?').get(email);
    if (existing) {
      return res.status(400).json({ error: 'Email already exists' });
    }

    const hashedPassword = await bcrypt.hash(password, 12);

    const result = db.prepare(`
      INSERT INTO support_staff (email, password, first_name, last_name, phone, assigned_by)
      VALUES (?, ?, ?, ?, ?, ?)
    `).run(email, hashedPassword, firstName, lastName, phone, req.admin.id);

    res.status(201).json({ message: 'Support staff created', id: result.lastInsertRowid });
  } catch (error) {
    console.error('Create support error:', error);
    res.status(500).json({ error: 'Failed to create support staff' });
  }
});

// Deactivate support staff
router.put('/support-staff/:id/deactivate', authenticateAdmin, (req, res) => {
  try {
    db.prepare('UPDATE support_staff SET is_active = 0 WHERE id = ?').run(req.params.id);
    res.json({ message: 'Support staff deactivated' });
  } catch (error) {
    console.error('Deactivate support error:', error);
    res.status(500).json({ error: 'Failed to deactivate support staff' });
  }
});

// Get traffic sources
router.get('/traffic', authenticateAdmin, (req, res) => {
  try {
    const trafficByReferrer = db.prepare(`
      SELECT referrer, COUNT(*) as count
      FROM analytics
      WHERE referrer IS NOT NULL
      GROUP BY referrer
      ORDER BY count DESC
      LIMIT 10
    `).all();

    const trafficByPage = db.prepare(`
      SELECT page, COUNT(*) as count
      FROM analytics
      GROUP BY page
      ORDER BY count DESC
      LIMIT 10
    `).all();

    const dailyTraffic = db.prepare(`
      SELECT date(created_at) as date, COUNT(*) as count
      FROM analytics
      GROUP BY date(created_at)
      ORDER BY date DESC
      LIMIT 30
    `).all();

    res.json({ trafficByReferrer, trafficByPage, dailyTraffic });
  } catch (error) {
    console.error('Traffic error:', error);
    res.status(500).json({ error: 'Failed to fetch traffic data' });
  }
});

// Get all deals
router.get('/deals', authenticateAdmin, (req, res) => {
  try {
    const deals = db.prepare(`
      SELECT d.*, 
        buyer.first_name as buyer_name, seller.first_name as seller_name,
        p.title as property_title
      FROM deals d
      LEFT JOIN users buyer ON d.buyer_id = buyer.id
      LEFT JOIN users seller ON d.seller_id = seller.id
      LEFT JOIN properties p ON d.property_id = p.id
      ORDER BY d.created_at DESC
    `).all();

    res.json({ deals });
  } catch (error) {
    console.error('Deals error:', error);
    res.status(500).json({ error: 'Failed to fetch deals' });
  }
});

// Get all inspections
router.get('/inspections', authenticateAdmin, (req, res) => {
  try {
    const inspections = db.prepare(`
      SELECT i.*, p.title as property_title, p.address,
        u.first_name as user_name, a.first_name as agent_name
      FROM inspections i
      JOIN properties p ON i.property_id = p.id
      JOIN users u ON i.user_id = u.id
      LEFT JOIN agents a ON i.agent_id = a.id
      ORDER BY i.created_at DESC
    `).all();

    res.json({ inspections });
  } catch (error) {
    console.error('Inspections error:', error);
    res.status(500).json({ error: 'Failed to fetch inspections' });
  }
});

// Create press article
router.post('/press', authenticateAdmin, (req, res) => {
  try {
    const { title, content, excerpt, category, imageUrl } = req.body;

    const result = db.prepare(`
      INSERT INTO press_articles (title, content, excerpt, author_id, author_type, category, image_url)
      VALUES (?, ?, ?, ?, 'admin', ?, ?)
    `).run(title, content, excerpt, req.admin.id, category, imageUrl);

    res.status(201).json({ message: 'Article created', id: result.lastInsertRowid });
  } catch (error) {
    console.error('Create article error:', error);
    res.status(500).json({ error: 'Failed to create article' });
  }
});

module.exports = router;
// ===== FINANCE / COMMISSION ROUTES =====

// Get all commission rates
router.get('/finance/commission-rates', authenticateAdmin, (req, res) => {
  try {
    const rates = db.prepare('SELECT * FROM commission_rates ORDER BY role').all();
    res.json({ rates });
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch commission rates' });
  }
});

// Update a commission rate
router.put('/finance/commission-rates/:role', authenticateAdmin, (req, res) => {
  try {
    const { rate, description } = req.body;
    const { role } = req.params;
    if (rate === undefined || rate < 0 || rate > 100) {
      return res.status(400).json({ error: 'Rate must be between 0 and 100' });
    }
    db.prepare(`
      UPDATE commission_rates SET rate=?, description=?, updated_by=?, updated_at=CURRENT_TIMESTAMP
      WHERE role=?
    `).run(rate, description, req.admin.id, role);
    res.json({ message: 'Commission rate updated' });
  } catch (error) {
    res.status(500).json({ error: 'Failed to update commission rate' });
  }
});

// Get all inspection packages
router.get('/finance/inspection-packages', authenticateAdmin, (req, res) => {
  try {
    const packages = db.prepare('SELECT * FROM inspection_packages ORDER BY id').all();
    res.json({ packages });
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch inspection packages' });
  }
});

// Update an inspection package
router.put('/finance/inspection-packages/:id', authenticateAdmin, (req, res) => {
  try {
    const { name, price, description, commission_rate, is_active } = req.body;
    const { id } = req.params;
    db.prepare(`
      UPDATE inspection_packages SET name=?, price=?, description=?, commission_rate=?, is_active=?, updated_at=CURRENT_TIMESTAMP
      WHERE id=?
    `).run(name, price, description, commission_rate || 0, is_active !== undefined ? is_active : 1, id);
    res.json({ message: 'Package updated' });
  } catch (error) {
    res.status(500).json({ error: 'Failed to update package' });
  }
});

// Get finance overview stats
router.get('/finance/overview', authenticateAdmin, (req, res) => {
  try {
    const totalRevenue = db.prepare("SELECT COALESCE(SUM(amount),0) as total FROM payments WHERE status='success'").get();
    const totalDeals = db.prepare("SELECT COUNT(*) as cnt, COALESCE(SUM(commission_amount),0) as commission FROM deals WHERE escrow_status='completed'").get();
    const pendingPayments = db.prepare("SELECT COUNT(*) as cnt, COALESCE(SUM(amount),0) as total FROM payments WHERE status='pending'").get();
    const recentTransactions = db.prepare(`
      SELECT p.*, u.first_name, u.last_name FROM payments p
      LEFT JOIN users u ON p.user_id = u.id
      ORDER BY p.created_at DESC LIMIT 10
    `).all();
    res.json({ totalRevenue: totalRevenue.total, totalDeals: totalDeals.cnt, totalCommission: totalDeals.commission, pendingPayments, recentTransactions });
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch finance overview' });
  }
});

// ===== PROPERTY DOCUMENTS VERIFICATION (Admin) =====
router.get('/property-documents', authenticateAdmin, (req, res) => {
  try {
    const docs = db.prepare(`
      SELECT pd.*, u.first_name, u.last_name, u.email, p.title as property_title
      FROM property_documents pd
      JOIN users u ON pd.user_id = u.id
      LEFT JOIN properties p ON pd.property_id = p.id
      ORDER BY pd.created_at DESC
    `).all();
    res.json({ documents: docs });
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch property documents' });
  }
});
