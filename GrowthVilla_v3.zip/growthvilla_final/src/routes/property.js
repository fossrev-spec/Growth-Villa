const express = require('express');
const { db } = require('../models/database');
const { optionalAuth } = require('../middleware/auth');

const router = express.Router();

// Get all properties
router.get('/', (req, res) => {
  try {
    const { type, state, minPrice, maxPrice, bedrooms, page = 1, limit = 12 } = req.query;
    const offset = (page - 1) * limit;

    let query = `
      SELECT p.*, a.first_name as agent_name, a.rating as agent_rating
      FROM properties p
      LEFT JOIN agents a ON p.agent_id = a.id
      WHERE p.is_verified = 1
    `;
    const params = [];

    if (type) {
      query += ' AND p.listing_type = ?';
      params.push(type);
    }
    if (state) {
      query += ' AND p.state = ?';
      params.push(state);
    }
    if (minPrice) {
      query += ' AND p.price >= ?';
      params.push(minPrice);
    }
    if (maxPrice) {
      query += ' AND p.price <= ?';
      params.push(maxPrice);
    }
    if (bedrooms) {
      query += ' AND p.bedrooms >= ?';
      params.push(bedrooms);
    }

    query += ' ORDER BY p.created_at DESC LIMIT ? OFFSET ?';
    params.push(parseInt(limit), offset);

    const properties = db.prepare(query).all(...params);

    const totalQuery = `SELECT COUNT(*) as count FROM properties WHERE is_verified = 1`;
    const total = db.prepare(totalQuery).get();

    res.json({ properties, total: total.count, page: parseInt(page), limit: parseInt(limit) });
  } catch (error) {
    console.error('Properties error:', error);
    res.status(500).json({ error: 'Failed to fetch properties' });
  }
});

// Get single property
router.get('/:id', (req, res) => {
  try {
    const property = db.prepare(`
      SELECT p.*, 
        a.first_name as agent_first_name, a.last_name as agent_last_name, 
        a.phone as agent_phone, a.rating as agent_rating,
        u.first_name as owner_name
      FROM properties p
      LEFT JOIN agents a ON p.agent_id = a.id
      LEFT JOIN users u ON p.owner_id = u.id
      WHERE p.id = ?
    `).get(req.params.id);

    if (!property) {
      return res.status(404).json({ error: 'Property not found' });
    }

    // Increment views
    db.prepare('UPDATE properties SET views = views + 1 WHERE id = ?').run(req.params.id);

    res.json({ property });
  } catch (error) {
    console.error('Property error:', error);
    res.status(500).json({ error: 'Failed to fetch property' });
  }
});

// Book inspection
router.post('/:id/inspection', optionalAuth, (req, res) => {
  try {
    const { firstName, lastName, email, phone, preferredDate, preferredTime, inspectionType, state } = req.body;
    const propertyId = req.params.id;

    // Calculate inspection fee with updated pricing
    const FEES = {
      'basic': 43970,
      'structural': 84300,
      'title': 25000,
      'all': null // Dynamic - calculated based on property price
    };

    let fee;
    if (inspectionType === 'all') {
      // Calculate based on property price
      const property = db.prepare('SELECT price FROM properties WHERE id = ?').get(propertyId);
      const propertyPrice = property?.price || 0;
      
      if (propertyPrice < 700000) {
        fee = propertyPrice * 0.043; // 4.3%
      } else if (propertyPrice < 5000000) {
        fee = propertyPrice * 0.02; // 2%
      } else if (propertyPrice <= 10000000) {
        fee = propertyPrice * 0.025; // 2.5%
      } else {
        fee = propertyPrice * 0.053; // 5.3%
      }
      fee = Math.round(fee);
    } else {
      fee = FEES[inspectionType] || 43970;
    }
    const agentFee = fee * 0.7; // Agent gets 70%

    const result = db.prepare(`
      INSERT INTO inspections (property_id, user_id, state, inspection_type, scheduled_date, fee, agent_fee, status)
      VALUES (?, ?, ?, ?, ?, ?, ?, 'pending')
    `).run(propertyId, req.user?.id || null, state, inspectionType, preferredDate, fee, agentFee);

    // Get agents in that state with highest success rate
    const bestAgent = db.prepare(`
      SELECT id FROM agents 
      WHERE state = ? AND is_verified = 1 
      ORDER BY success_rate DESC, total_inspections DESC 
      LIMIT 1
    `).get(state);

    if (bestAgent) {
      // Assign to agent
      db.prepare(`
        UPDATE inspections SET agent_id = ?, status = 'assigned', assigned_at = CURRENT_TIMESTAMP
        WHERE id = ?
      `).run(bestAgent.id, result.lastInsertRowid);
    }

    // Return inspection fee info with commission
    const property = db.prepare('SELECT price FROM properties WHERE id = ?').get(propertyId);
    
    // Calculate verification fee tier info
    let verificationFeeRate;
    if (property?.price < 700000) {
      verificationFeeRate = 0.043;
    } else if (property?.price < 5000000) {
      verificationFeeRate = 0.02;
    } else if (property?.price <= 10000000) {
      verificationFeeRate = 0.025;
    } else {
      verificationFeeRate = 0.053;
    }

    res.status(201).json({
      message: 'Inspection booked successfully',
      inspectionId: result.lastInsertRowid,
      fee,
      agentFee,
      verificationFeeRate: verificationFeeRate * 100,
      verificationFeeRange: {
        min: property?.price * 0.01,
        max: property?.price * 0.053,
        description: 'Full property verification fee: Between 1-5% commission of property price'
      }
    });
  } catch (error) {
    console.error('Book inspection error:', error);
    res.status(500).json({ error: 'Failed to book inspection' });
  }
});

// Get shortlets
router.get('/shortlets/all', (req, res) => {
  try {
    const { state, minPrice, maxPrice, guests } = req.query;

    let query = `
      SELECT s.*, p.title, p.address, p.state, p.images
      FROM shortlets s
      JOIN properties p ON s.property_id = p.id
      WHERE s.is_available = 1
    `;
    const params = [];

    if (state) {
      query += ' AND p.state = ?';
      params.push(state);
    }
    if (minPrice) {
      query += ' AND s.price_per_night >= ?';
      params.push(minPrice);
    }
    if (maxPrice) {
      query += ' AND s.price_per_night <= ?';
      params.push(maxPrice);
    }

    query += ' ORDER BY s.rating DESC';

    const shortlets = db.prepare(query).all(...params);

    res.json({ shortlets });
  } catch (error) {
    console.error('Shortlets error:', error);
    res.status(500).json({ error: 'Failed to fetch shortlets' });
  }
});

// Book shortlet
router.post('/shortlets/:id/book', optionalAuth, (req, res) => {
  try {
    const { checkIn, checkOut, guests } = req.body;
    const shortletId = req.params.id;

    const shortlet = db.prepare(`
      SELECT s.*, p.title FROM shortlets s
      JOIN properties p ON s.property_id = p.id
      WHERE s.id = ?
    `).get(shortletId);

    if (!shortlet) {
      return res.status(404).json({ error: 'Shortlet not found' });
    }

    // Calculate total
    const nights = Math.ceil((new Date(checkOut) - new Date(checkIn)) / (1000 * 60 * 60 * 24));
    const totalAmount = nights * shortlet.price_per_night;

    const result = db.prepare(`
      INSERT INTO shortlet_bookings (shortlet_id, user_id, check_in, check_out, guests, total_amount, status)
      VALUES (?, ?, ?, ?, ?, ?, 'pending')
    `).run(shortletId, req.user?.id || null, checkIn, checkOut, guests, totalAmount);

    res.status(201).json({
      message: 'Booking created',
      bookingId: result.lastInsertRowid,
      totalAmount,
      nights
    });
  } catch (error) {
    console.error('Book shortlet error:', error);
    res.status(500).json({ error: 'Failed to book shortlet' });
  }
});

// Calculate verification fee based on property price
router.post('/calculate-verification-fee', (req, res) => {
  try {
    const { propertyPrice } = req.body;
    const price = parseFloat(propertyPrice);

    if (!price || price <= 0) {
      return res.status(400).json({ error: 'Valid property price is required' });
    }

    let rate;
    let tier;

    if (price < 700000) {
      rate = 0.043; // 4.3%
      tier = 'below_700k';
    } else if (price < 5000000) {
      rate = 0.02; // 2%
      tier = 'below_5m';
    } else if (price <= 10000000) {
      rate = 0.025; // 2.5%
      tier = '5m_to_10m';
    } else {
      rate = 0.053; // 5.3%
      tier = 'above_10m';
    }

    const verificationFee = price * rate;

    // Updated inspection package fees
    const packages = {
      basicSnagging: 43970,
      structuralIndepthSnagging: 84300,
      titleCheckOnly: 25000,
      allInOneComplete: verificationFee // Dynamic based on property price
    };

    res.json({
      propertyPrice: price,
      tier,
      rate: rate * 100, // Return as percentage
      verificationFee: Math.round(verificationFee),
      formattedFee: `₦${Math.round(verificationFee).toLocaleString()}`,
      packages: {
        basicSnagging: {
          name: 'Basic Snagging',
          price: packages.basicSnagging,
          formatted: `₦${packages.basicSnagging.toLocaleString()}`
        },
        structuralIndepthSnagging: {
          name: 'Structural + Indepth Snagging',
          price: packages.structuralIndepthSnagging,
          formatted: `₦${packages.structuralIndepthSnagging.toLocaleString()}`
        },
        titleCheckOnly: {
          name: 'Title Check Only',
          price: packages.titleCheckOnly,
          formatted: `₦${packages.titleCheckOnly.toLocaleString()}`
        },
        allInOneComplete: {
          name: 'All-in-One Complete Verification',
          price: packages.allInOneComplete,
          formatted: `₦${Math.round(packages.allInOneComplete).toLocaleString()}`,
          isDynamic: true
        }
      },
      description: 'Full property verification fee: Between 1-5% commission of property price'
    });
  } catch (error) {
    console.error('Calculate verification fee error:', error);
    res.status(500).json({ error: 'Failed to calculate verification fee' });
  }
});

// Get verified agents
router.get('/agents/verified', (req, res) => {
  try {
    const { state, limit = 8 } = req.query;

    let query = `
      SELECT id, first_name, last_name, state, success_rate, total_inspections, rating, specialty
      FROM agents WHERE is_verified = 1
    `;
    const params = [];

    if (state) {
      query += ' AND state = ?';
      params.push(state);
    }

    query += ' ORDER BY rating DESC, success_rate DESC LIMIT ?';
    params.push(parseInt(limit));

    const agents = db.prepare(query).all(...params);

    res.json({ agents });
  } catch (error) {
    console.error('Agents error:', error);
    res.status(500).json({ error: 'Failed to fetch agents' });
  }
});

module.exports = router;