const express = require('express');
const { db } = require('../models/database');
const { authenticateAgent, requireAgentVerification } = require('../middleware/auth');

const router = express.Router();

// Get agent profile
router.get('/profile', authenticateAgent, (req, res) => {
  try {
    const agent = db.prepare(`
      SELECT id, email, first_name, last_name, phone, state, license_number, 
        experience_years, is_verified, success_rate, total_inspections, 
        successful_deals, rating, commission_earned, created_at
      FROM agents WHERE id = ?
    `).get(req.agent.id);

    res.json({ agent });
  } catch (error) {
    console.error('Profile error:', error);
    res.status(500).json({ error: 'Failed to fetch profile' });
  }
});

// Get assigned inspections
router.get('/inspections', authenticateAgent, (req, res) => {
  try {
    const inspections = db.prepare(`
      SELECT i.*, p.title, p.address, p.state, p.price,
        u.first_name as user_first_name, u.last_name as user_last_name, u.phone as user_phone
      FROM inspections i
      JOIN properties p ON i.property_id = p.id
      JOIN users u ON i.user_id = u.id
      WHERE i.agent_id = ?
      ORDER BY i.scheduled_date ASC
    `).all(req.agent.id);

    res.json({ inspections });
  } catch (error) {
    console.error('Inspections error:', error);
    res.status(500).json({ error: 'Failed to fetch inspections' });
  }
});

// Complete inspection
router.put('/inspections/:id/complete', authenticateAgent, requireAgentVerification, (req, res) => {
  try {
    const { reportUrl } = req.body;

    db.prepare(`
      UPDATE inspections 
      SET status = 'completed', report_url = ?, completed_at = CURRENT_TIMESTAMP
      WHERE id = ? AND agent_id = ?
    `).run(reportUrl, req.params.id, req.agent.id);

    // Update agent stats
    db.prepare(`
      UPDATE agents 
      SET total_inspections = total_inspections + 1
      WHERE id = ?
    `).run(req.agent.id);

    res.json({ message: 'Inspection completed successfully' });
  } catch (error) {
    console.error('Complete inspection error:', error);
    res.status(500).json({ error: 'Failed to complete inspection' });
  }
});

// Get agent's properties (for selling)
router.get('/properties', authenticateAgent, (req, res) => {
  try {
    const properties = db.prepare(`
      SELECT * FROM properties WHERE agent_id = ? ORDER BY created_at DESC
    `).all(req.agent.id);

    res.json({ properties });
  } catch (error) {
    console.error('Properties error:', error);
    res.status(500).json({ error: 'Failed to fetch properties' });
  }
});

// Add property for sale
router.post('/properties', authenticateAgent, requireAgentVerification, (req, res) => {
  try {
    const { title, description, price, propertyType, listingType, state, lga, address, bedrooms, bathrooms, sqm, images } = req.body;

    const result = db.prepare(`
      INSERT INTO properties (title, description, price, property_type, listing_type, state, lga, address, bedrooms, bathrooms, sqm, images, agent_id, is_verified)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1)
    `).run(title, description, price, propertyType, listingType, state, lga, address, bedrooms, bathrooms, sqm, JSON.stringify(images), req.agent.id);

    res.status(201).json({ message: 'Property added successfully', id: result.lastInsertRowid });
  } catch (error) {
    console.error('Add property error:', error);
    res.status(500).json({ error: 'Failed to add property' });
  }
});

// Get earnings
router.get('/earnings', authenticateAgent, (req, res) => {
  try {
    const earnings = db.prepare(`
      SELECT i.id, i.fee, i.agent_fee, i.completed_at, p.title, p.address
      FROM inspections i
      JOIN properties p ON i.property_id = p.id
      WHERE i.agent_id = ? AND i.status = 'completed' AND i.payment_status = 'paid'
      ORDER BY i.completed_at DESC
    `).all(req.agent.id);

    const totalEarnings = db.prepare(`
      SELECT SUM(agent_fee) as total FROM inspections 
      WHERE agent_id = ? AND status = 'completed' AND payment_status = 'paid'
    `).get(req.agent.id);

    res.json({ earnings, totalEarnings: totalEarnings.total || 0 });
  } catch (error) {
    console.error('Earnings error:', error);
    res.status(500).json({ error: 'Failed to fetch earnings' });
  }
});

// Get deals involving agent
router.get('/deals', authenticateAgent, (req, res) => {
  try {
    const deals = db.prepare(`
      SELECT d.*, p.title, p.address, p.state,
        buyer.first_name as buyer_name, seller.first_name as seller_name
      FROM deals d
      JOIN properties p ON d.property_id = p.id
      LEFT JOIN users buyer ON d.buyer_id = buyer.id
      LEFT JOIN users seller ON d.seller_id = seller.id
      WHERE d.agent_id = ?
      ORDER BY d.created_at DESC
    `).all(req.agent.id);

    res.json({ deals });
  } catch (error) {
    console.error('Deals error:', error);
    res.status(500).json({ error: 'Failed to fetch deals' });
  }
});

// Property title search verification
router.post('/title-search', authenticateAgent, (req, res) => {
  try {
    const { propertyId, searchType } = req.body;

    // Simulate title search from Nigerian property valuation sites
    const titleData = {
      status: 'verified',
      source: searchType === 'lagos' ? 'Lagos e-GIS' : 
              searchType === 'abuja' ? 'Abuja AGIS' : 
              'State Land Registry',
      verifiedAt: new Date().toISOString(),
      certificateNumber: `CERT-${Date.now()}`,
      verifiedBy: 'Government Portal'
    };

    // Update property verification
    db.prepare(`
      UPDATE properties SET verification_status = 'title_verified'
      WHERE id = ?
    `).run(propertyId);

    res.json({ titleData });
  } catch (error) {
    console.error('Title search error:', error);
    res.status(500).json({ error: 'Failed to perform title search' });
  }
});

// Upload verification documents
router.post('/documents', authenticateAgent, (req, res) => {
  try {
    const { documentType, documentUrl } = req.body;

    const result = db.prepare(`
      INSERT INTO document_verifications (agent_id, document_type, document_url, status)
      VALUES (?, ?, ?, 'pending')
    `).run(req.agent.id, documentType, documentUrl);

    res.status(201).json({ message: 'Document uploaded', id: result.lastInsertRowid });
  } catch (error) {
    console.error('Upload document error:', error);
    res.status(500).json({ error: 'Failed to upload document' });
  }
});


// ===== PROPERTY DOCUMENT VERIFICATION (Agent) =====

// Get all pending property documents for agent review
router.get('/property-documents', authenticateAgent, (req, res) => {
  try {
    const docs = db.prepare(`
      SELECT pd.*, u.first_name, u.last_name, u.email, u.phone, p.title as property_title, p.address as property_address
      FROM property_documents pd
      JOIN users u ON pd.user_id = u.id
      LEFT JOIN properties p ON pd.property_id = p.id
      ORDER BY pd.created_at DESC
    `).all();
    res.json({ documents: docs });
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch property documents' });
  }
});

// Verify or reject a property document
router.put('/property-documents/:id/verify', authenticateAgent, (req, res) => {
  try {
    const { status, agent_notes } = req.body;
    if (!['verified', 'rejected'].includes(status)) {
      return res.status(400).json({ error: 'Status must be verified or rejected' });
    }
    const doc = db.prepare('SELECT * FROM property_documents WHERE id=?').get(req.params.id);
    if (!doc) return res.status(404).json({ error: 'Document not found' });
    
    db.prepare(`
      UPDATE property_documents SET status=?, verified_by=?, verified_at=CURRENT_TIMESTAMP, agent_notes=?
      WHERE id=?
    `).run(status, req.agent.id, agent_notes || '', req.params.id);
    res.json({ message: `Document ${status} successfully` });
  } catch (error) {
    res.status(500).json({ error: 'Failed to update document status' });
  }
});

module.exports = router;