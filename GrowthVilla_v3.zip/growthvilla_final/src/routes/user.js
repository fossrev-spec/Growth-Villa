const express = require('express');
const CryptoJS = require('crypto-js');
const { db } = require('../models/database');
const { authenticateUser, requireVerification } = require('../middleware/auth');

const router = express.Router();
const ENCRYPTION_KEY = process.env.ENCRYPTION_KEY || 'growthvilla-encryption-key-2024';

const encryptData = (data) => {
  return CryptoJS.AES.encrypt(data, ENCRYPTION_KEY).toString();
};

// Get user profile
router.get('/profile', authenticateUser, (req, res) => {
  try {
    const user = db.prepare(`
      SELECT id, email, first_name, last_name, phone, nin, bvn, is_verified, verification_status, created_at
      FROM users WHERE id = ?
    `).get(req.user.id);

    if (!user) {
      return res.status(404).json({ error: 'User not found' });
    }

    res.json({ user });
  } catch (error) {
    console.error('Profile error:', error);
    res.status(500).json({ error: 'Failed to fetch profile' });
  }
});

// Update user profile
router.put('/profile', authenticateUser, (req, res) => {
  try {
    const { firstName, lastName, phone, nin, bvn } = req.body;

    const encryptedNin = nin ? encryptData(nin) : null;
    const encryptedBvn = bvn ? encryptData(bvn) : null;

    db.prepare(`
      UPDATE users 
      SET first_name = ?, last_name = ?, phone = ?, nin = ?, bvn = ?, updated_at = CURRENT_TIMESTAMP
      WHERE id = ?
    `).run(firstName, lastName, phone, encryptedNin, encryptedBvn, req.user.id);

    res.json({ message: 'Profile updated successfully' });
  } catch (error) {
    console.error('Update profile error:', error);
    res.status(500).json({ error: 'Failed to update profile' });
  }
});

// Get user's valuations
router.get('/valuations', authenticateUser, (req, res) => {
  try {
    const valuations = db.prepare(`
      SELECT * FROM valuations WHERE user_id = ? ORDER BY created_at DESC
    `).all(req.user.id);

    res.json({ valuations });
  } catch (error) {
    console.error('Valuations error:', error);
    res.status(500).json({ error: 'Failed to fetch valuations' });
  }
});

// Get user's deals
router.get('/deals', authenticateUser, (req, res) => {
  try {
    const dealsAsBuyer = db.prepare(`
      SELECT d.*, p.title, p.address, p.state, p.price
      FROM deals d
      JOIN properties p ON d.property_id = p.id
      WHERE d.buyer_id = ?
      ORDER BY d.created_at DESC
    `).all(req.user.id);

    const dealsAsSeller = db.prepare(`
      SELECT d.*, p.title, p.address, p.state, p.price
      FROM deals d
      JOIN properties p ON d.property_id = p.id
      WHERE d.seller_id = ?
      ORDER BY d.created_at DESC
    `).all(req.user.id);

    res.json({ dealsAsBuyer, dealsAsSeller });
  } catch (error) {
    console.error('Deals error:', error);
    res.status(500).json({ error: 'Failed to fetch deals' });
  }
});

// Get user's inspections
router.get('/inspections', authenticateUser, (req, res) => {
  try {
    const inspections = db.prepare(`
      SELECT i.*, p.title, p.address, p.state,
        a.first_name as agent_first_name, a.last_name as agent_last_name
      FROM inspections i
      JOIN properties p ON i.property_id = p.id
      LEFT JOIN agents a ON i.agent_id = a.id
      WHERE i.user_id = ?
      ORDER BY i.created_at DESC
    `).all(req.user.id);

    res.json({ inspections });
  } catch (error) {
    console.error('Inspections error:', error);
    res.status(500).json({ error: 'Failed to fetch inspections' });
  }
});

// Get co-renting matches
router.get('/corenting', authenticateUser, (req, res) => {
  try {
    const corentingList = db.prepare(`
      SELECT * FROM corenting WHERE user_id = ? ORDER BY created_at DESC
    `).all(req.user.id);

    res.json({ corenting: corentingList });
  } catch (error) {
    console.error('Co-renting error:', error);
    res.status(500).json({ error: 'Failed to fetch co-renting data' });
  }
});

// Create co-renting request
router.post('/corenting', authenticateUser, (req, res) => {
  try {
    const { title, description, budgetMin, budgetMax, state, area, preferences, lifestyle, moveInDate } = req.body;

    const result = db.prepare(`
      INSERT INTO corenting (user_id, title, description, budget_min, budget_max, state, area, preferences, lifestyle, move_in_date)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).run(req.user.id, title, description, budgetMin, budgetMax, state, area, JSON.stringify(preferences), JSON.stringify(lifestyle), moveInDate);

    res.status(201).json({ message: 'Co-renting request created', id: result.lastInsertRowid });
  } catch (error) {
    console.error('Create co-renting error:', error);
    res.status(500).json({ error: 'Failed to create co-renting request' });
  }
});

// Get growth estimate (valuation)
router.post('/valuation', authenticateUser, (req, res) => {
  try {
    const { address, state, propertyType, bedrooms, sqm } = req.body;

    // State data for calculation
    const STATE_DATA = {
      "Lagos": { pricePerSqm: 180000, growth: 39.46, yield: 8.5 },
      "FCT Abuja": { pricePerSqm: 150000, growth: 25.3, yield: 7.8 },
      "Rivers": { pricePerSqm: 85000, growth: 18.2, yield: 9.2 },
      "Ogun": { pricePerSqm: 45000, growth: 30.48, yield: 10.5 },
      "Kano": { pricePerSqm: 35000, growth: 12.5, yield: 11.2 },
      "Anambra": { pricePerSqm: 55000, growth: 28.24, yield: 9.8 },
      "Oyo": { pricePerSqm: 40000, growth: 29.89, yield: 10.2 },
      "Enugu": { pricePerSqm: 48000, growth: 22.1, yield: 9.5 }
    };

    const stateData = STATE_DATA[state] || { pricePerSqm: 25000, growth: 10, yield: 12 };
    
    const estimatedValue = stateData.pricePerSqm * (sqm || 200);
    const variance = 0.15;
    const lowRange = Math.round(estimatedValue * (1 - variance));
    const highRange = Math.round(estimatedValue * (1 + variance));

    const result = db.prepare(`
      INSERT INTO valuations (user_id, address, state, property_type, bedrooms, sqm, estimated_value, low_range, high_range, price_per_sqm, growth_rate, rental_yield)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).run(req.user.id, address, state, propertyType, bedrooms, sqm, estimatedValue, lowRange, highRange, stateData.pricePerSqm, stateData.growth, stateData.yield);

    res.json({
      valuation: {
        id: result.lastInsertRowid,
        estimatedValue,
        lowRange,
        highRange,
        pricePerSqm: stateData.pricePerSqm,
        growthRate: stateData.growth,
        rentalYield: stateData.yield
      }
    });
  } catch (error) {
    console.error('Valuation error:', error);
    res.status(500).json({ error: 'Failed to calculate valuation' });
  }
});

// List property (for verified users)
router.post('/properties', authenticateUser, requireVerification, (req, res) => {
  try {
    const { title, description, price, propertyType, listingType, state, lga, address, bedrooms, bathrooms, sqm } = req.body;

    const result = db.prepare(`
      INSERT INTO properties (title, description, price, property_type, listing_type, state, lga, address, bedrooms, bathrooms, sqm, owner_id)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).run(title, description, price, propertyType, listingType, state, lga, address, bedrooms, bathrooms, sqm, req.user.id);

    res.status(201).json({ message: 'Property listed successfully', id: result.lastInsertRowid });
  } catch (error) {
    console.error('List property error:', error);
    res.status(500).json({ error: 'Failed to list property' });
  }
});

// Get shortlet bookings
router.get('/shortlet-bookings', authenticateUser, (req, res) => {
  try {
    const bookings = db.prepare(`
      SELECT sb.*, s.price_per_night, p.title, p.address, p.state
      FROM shortlet_bookings sb
      JOIN shortlets s ON sb.shortlet_id = s.id
      JOIN properties p ON s.property_id = p.id
      WHERE sb.user_id = ?
      ORDER BY sb.created_at DESC
    `).all(req.user.id);

    res.json({ bookings });
  } catch (error) {
    console.error('Shortlet bookings error:', error);
    res.status(500).json({ error: 'Failed to fetch bookings' });
  }
});


// ===== PROPERTY DOCUMENT ROUTES =====

// Upload property document (base64 stored as data URL or path)
router.post('/property-documents', authenticateUser, (req, res) => {
  try {
    const { documentType, documentName, documentUrl, propertyId, fileSize } = req.body;
    if (!documentType || !documentName || !documentUrl) {
      return res.status(400).json({ error: 'Document type, name, and file are required' });
    }
    const result = db.prepare(`
      INSERT INTO property_documents (user_id, property_id, document_type, document_name, document_url, file_size, status)
      VALUES (?, ?, ?, ?, ?, ?, 'pending')
    `).run(req.user.id, propertyId || null, documentType, documentName, documentUrl, fileSize || 0);
    res.status(201).json({ message: 'Document uploaded successfully', id: result.lastInsertRowid });
  } catch (error) {
    console.error('Upload property doc error:', error);
    res.status(500).json({ error: 'Failed to upload document' });
  }
});

// Get user's property documents
router.get('/property-documents', authenticateUser, (req, res) => {
  try {
    const docs = db.prepare(`
      SELECT pd.*, p.title as property_title
      FROM property_documents pd
      LEFT JOIN properties p ON pd.property_id = p.id
      WHERE pd.user_id = ?
      ORDER BY pd.created_at DESC
    `).all(req.user.id);
    res.json({ documents: docs });
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch documents' });
  }
});

// Delete a property document
router.delete('/property-documents/:id', authenticateUser, (req, res) => {
  try {
    const doc = db.prepare('SELECT * FROM property_documents WHERE id=? AND user_id=?').get(req.params.id, req.user.id);
    if (!doc) return res.status(404).json({ error: 'Document not found' });
    if (doc.status === 'verified') return res.status(400).json({ error: 'Cannot delete a verified document' });
    db.prepare('DELETE FROM property_documents WHERE id=?').run(req.params.id);
    res.json({ message: 'Document deleted' });
  } catch (error) {
    res.status(500).json({ error: 'Failed to delete document' });
  }
});

// Get public inspection packages (for booking form)
router.get('/inspection-packages', (req, res) => {
  try {
    const packages = db.prepare('SELECT * FROM inspection_packages WHERE is_active=1 ORDER BY id').all();
    res.json({ packages });
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch packages' });
  }
});

module.exports = router;