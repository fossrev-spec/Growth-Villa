const express = require('express');
const { db } = require('../models/database');

const router = express.Router();

// Get all published articles
router.get('/', (req, res) => {
  try {
    const { category, limit = 20, page = 1 } = req.query;
    const offset = (page - 1) * limit;

    let query = `
      SELECT p.*, 
        CASE 
          WHEN p.author_type = 'admin' THEN a.first_name
          WHEN p.author_type = 'support' THEN s.first_name
        END as author_name
      FROM press_articles p
      LEFT JOIN admins a ON p.author_type = 'admin' AND p.author_id = a.id
      LEFT JOIN support_staff s ON p.author_type = 'support' AND p.author_id = s.id
      WHERE p.is_published = 1
    `;
    const params = [];

    if (category) {
      query += ' AND p.category = ?';
      params.push(category);
    }

    query += ' ORDER BY p.created_at DESC LIMIT ? OFFSET ?';
    params.push(parseInt(limit), offset);

    const articles = db.prepare(query).all(...params);

    res.json({ articles });
  } catch (error) {
    console.error('Articles error:', error);
    res.status(500).json({ error: 'Failed to fetch articles' });
  }
});

// Get single article
router.get('/:id', (req, res) => {
  try {
    const article = db.prepare(`
      SELECT p.*, 
        CASE 
          WHEN p.author_type = 'admin' THEN a.first_name
          WHEN p.author_type = 'support' THEN s.first_name
        END as author_name
      FROM press_articles p
      LEFT JOIN admins a ON p.author_type = 'admin' AND p.author_id = a.id
      LEFT JOIN support_staff s ON p.author_type = 'support' AND p.author_id = s.id
      WHERE p.id = ?
    `).get(req.params.id);

    if (!article) {
      return res.status(404).json({ error: 'Article not found' });
    }

    // Increment views
    db.prepare('UPDATE press_articles SET views = views + 1 WHERE id = ?').run(req.params.id);

    res.json({ article });
  } catch (error) {
    console.error('Article error:', error);
    res.status(500).json({ error: 'Failed to fetch article' });
  }
});

// Get categories
router.get('/categories/list', (req, res) => {
  try {
    const categories = db.prepare(`
      SELECT category, COUNT(*) as count
      FROM press_articles
      WHERE is_published = 1
      GROUP BY category
      ORDER BY count DESC
    `).all();

    res.json({ categories });
  } catch (error) {
    console.error('Categories error:', error);
    res.status(500).json({ error: 'Failed to fetch categories' });
  }
});

module.exports = router;