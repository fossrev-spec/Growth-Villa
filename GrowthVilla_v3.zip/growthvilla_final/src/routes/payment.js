const express = require('express');
const { db } = require('../models/database');
const { optionalAuth } = require('../middleware/auth');

const router = express.Router();

// Paystack configuration
const PAYSTACK_SECRET_KEY = process.env.PAYSTACK_SECRET_KEY || 'sk_test_xxx';

// AtaraPay configuration (Escrow)
const ATARAPAY_API_KEY = process.env.ATARAPAY_API_KEY || 'atarapay_test_key';

// Initialize Paystack payment for inspection
router.post('/paystack/initialize', optionalAuth, async (req, res) => {
  try {
    const { inspectionId, email, amount } = req.body;

    // Create payment record
    const reference = `GV-INS-${Date.now()}`;
    
    const result = db.prepare(`
      INSERT INTO payments (user_id, amount, payment_type, reference, status, metadata)
      VALUES (?, ?, 'inspection', ?, 'pending', ?)
    `).run(req.user?.id || null, amount, reference, JSON.stringify({ inspectionId }));

    // In production, call Paystack API
    const paystackResponse = {
      status: true,
      message: 'Authorization URL created',
      data: {
        authorization_url: `https://checkout.paystack.com/${reference}`,
        access_code: reference,
        reference: reference
      }
    };

    res.json(paystackResponse);
  } catch (error) {
    console.error('Paystack initialize error:', error);
    res.status(500).json({ error: 'Failed to initialize payment' });
  }
});

// Paystack webhook
router.post('/paystack/webhook', (req, res) => {
  try {
    const { event, data } = req.body;

    if (event === 'charge.success') {
      const reference = data.reference;
      
      // Update payment status
      db.prepare(`
        UPDATE payments SET status = 'completed', paystack_reference = ? WHERE reference = ?
      `).run(data.id, reference);

      // Get payment details
      const payment = db.prepare('SELECT * FROM payments WHERE reference = ?').get(reference);
      
      if (payment) {
        const metadata = JSON.parse(payment.metadata || '{}');
        
        // Update inspection payment status
        if (metadata.inspectionId) {
          db.prepare(`
            UPDATE inspections SET payment_status = 'paid' WHERE id = ?
          `).run(metadata.inspectionId);
        }
      }
    }

    res.json({ status: 'success' });
  } catch (error) {
    console.error('Paystack webhook error:', error);
    res.status(500).json({ error: 'Webhook processing failed' });
  }
});

// Verify Paystack payment
router.get('/paystack/verify/:reference', async (req, res) => {
  try {
    const { reference } = req.params;

    // In production, verify with Paystack API
    const payment = db.prepare('SELECT * FROM payments WHERE reference = ?').get(reference);

    if (!payment) {
      return res.status(404).json({ error: 'Payment not found' });
    }

    res.json({
      status: payment.status,
      amount: payment.amount,
      reference: payment.reference
    });
  } catch (error) {
    console.error('Verify payment error:', error);
    res.status(500).json({ error: 'Failed to verify payment' });
  }
});

// Initialize AtaraPay escrow for deals
router.post('/atarapay/escrow', optionalAuth, async (req, res) => {
  try {
    const { dealId, buyerEmail, sellerEmail, amount } = req.body;

    // Calculate commission
    const commissionPercentage = 1.9; // GrowthVilla takes 1.9% from both buyer and seller
    const commissionAmount = amount * (commissionPercentage / 100) * 2;

    // Create escrow reference
    const escrowReference = `GV-ESC-${Date.now()}`;

    // Update deal
    db.prepare(`
      UPDATE deals SET 
        commission_percentage = ?, 
        commission_amount = ?, 
        payment_reference = ?,
        escrow_status = 'initiated'
      WHERE id = ?
    `).run(commissionPercentage, commissionAmount, escrowReference, dealId);

    // In production, call AtaraPay API
    const atarapayResponse = {
      status: true,
      message: 'Escrow created successfully',
      data: {
        escrow_id: escrowReference,
        escrow_url: `https://atarapay.com/escrow/${escrowReference}`,
        buyer_email: buyerEmail,
        seller_email: sellerEmail,
        amount: amount,
        commission: commissionAmount,
        platform_fee: amount * 0.019 * 2 // Both buyer and seller pay 1.9%
      }
    };

    // Create payment record
    db.prepare(`
      INSERT INTO payments (user_id, amount, payment_type, reference, atarapay_reference, status, metadata)
      VALUES (?, ?, 'escrow', ?, ?, 'pending', ?)
    `).run(req.user?.id || null, amount, escrowReference, escrowReference, JSON.stringify({ dealId }));

    res.json(atarapayResponse);
  } catch (error) {
    console.error('AtaraPay escrow error:', error);
    res.status(500).json({ error: 'Failed to create escrow' });
  }
});

// AtaraPay webhook
router.post('/atarapay/webhook', (req, res) => {
  try {
    const { event, data } = req.body;

    if (event === 'escrow.completed' || event === 'escrow.released') {
      const escrowReference = data.escrow_id;

      // Update payment
      db.prepare(`
        UPDATE payments SET status = 'completed' WHERE reference = ?
      `).run(escrowReference);

      // Update deal
      const payment = db.prepare('SELECT metadata FROM payments WHERE reference = ?').get(escrowReference);
      if (payment) {
        const metadata = JSON.parse(payment.metadata || '{}');
        db.prepare(`
          UPDATE deals SET escrow_status = 'completed', completed_at = CURRENT_TIMESTAMP WHERE id = ?
        `).run(metadata.dealId);
      }
    }

    res.json({ status: 'success' });
  } catch (error) {
    console.error('AtaraPay webhook error:', error);
    res.status(500).json({ error: 'Webhook processing failed' });
  }
});

// Calculate deal fees
router.post('/calculate-fees', (req, res) => {
  try {
    const { amount, dealType } = req.body;

    let buyerFee, sellerFee, totalCommission;

    switch (dealType) {
      case 'sale':
      case 'rent':
        buyerFee = amount * 0.019; // 1.9%
        sellerFee = amount * 0.019; // 1.9%
        totalCommission = buyerFee + sellerFee;
        break;
      case 'shortlet':
        buyerFee = amount * 0.019; // 1.9%
        sellerFee = amount * 0.019; // 1.9%
        totalCommission = buyerFee + sellerFee;
        break;
      case 'corent':
        buyerFee = amount * 0.005; // 0.5%
        sellerFee = amount * 0.005; // 0.5%
        totalCommission = buyerFee + sellerFee;
        break;
      default:
        buyerFee = amount * 0.019;
        sellerFee = amount * 0.019;
        totalCommission = buyerFee + sellerFee;
    }

    res.json({
      buyerFee,
      sellerFee,
      totalCommission,
      buyerPercentage: dealType === 'corent' ? '0.5%' : '1.9%',
      sellerPercentage: dealType === 'corent' ? '0.5%' : '1.9%'
    });
  } catch (error) {
    console.error('Calculate fees error:', error);
    res.status(500).json({ error: 'Failed to calculate fees' });
  }
});

module.exports = router;